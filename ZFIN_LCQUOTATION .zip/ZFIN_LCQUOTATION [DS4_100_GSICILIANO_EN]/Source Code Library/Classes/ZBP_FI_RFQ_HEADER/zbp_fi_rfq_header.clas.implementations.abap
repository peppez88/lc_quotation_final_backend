CLASS lhc_rfqheader DEFINITION INHERITING FROM cl_abap_behavior_handler.
  PRIVATE SECTION.
    METHODS earlynumbering_create FOR NUMBERING
      IMPORTING entities FOR CREATE RfqHeader.
    METHODS set_status_on_create FOR DETERMINE ON MODIFY
      IMPORTING keys FOR RfqHeader~set_status_on_create.
*    METHODS check_etag_on_modify FOR DETERMINE ON MODIFY
*      IMPORTING keys FOR RfqHeader~check_etag_on_modify.
    METHODS SendNotification FOR MODIFY
      IMPORTING keys FOR ACTION RfqHeader~SendNotification.
    METHODS SendPdfToBank FOR MODIFY
      IMPORTING keys FOR ACTION RfqHeader~SendPdfToBank.

    METHODS SubmitToBanking FOR MODIFY
      IMPORTING keys FOR ACTION RfqHeader~SubmitToBanking RESULT result.
    METHODS RejectByBanking FOR MODIFY
      IMPORTING keys FOR ACTION RfqHeader~RejectByBanking RESULT result.
    METHODS TakeOwnership FOR MODIFY
      IMPORTING keys FOR ACTION RfqHeader~TakeOwnership RESULT result.
    METHODS SendRfqToBanks FOR MODIFY
      IMPORTING keys FOR ACTION RfqHeader~SendRfqToBanks RESULT result.
    METHODS CancelEnquiry FOR MODIFY
      IMPORTING keys FOR ACTION RfqHeader~CancelEnquiry RESULT result.
    METHODS CloseEnquiry FOR MODIFY
      IMPORTING keys FOR ACTION RfqHeader~CloseEnquiry RESULT result.
    METHODS CompleteProcess FOR MODIFY
      IMPORTING keys FOR ACTION RfqHeader~CompleteProcess RESULT result.
    METHODS OnlySaveHistory FOR MODIFY
      IMPORTING keys FOR ACTION RfqHeader~OnlySaveHistory RESULT result.

    METHODS get_instance_authorizations FOR INSTANCE AUTHORIZATION
      IMPORTING keys REQUEST requested_authorizations FOR RfqHeader RESULT result.

    METHODS validate_bukrs FOR VALIDATE ON SAVE
      IMPORTING keys FOR RfqHeader~validate_bukrs.

    METHODS write_history
      IMPORTING iv_enqid         TYPE zzfirfq_enqid
                iv_action        TYPE zzfirfq_actions
                iv_status_old    TYPE zzfirfq_enqstatus
                iv_status_new    TYPE zzfirfq_enqstatus
                iv_reject_reason TYPE zzfirfq_rejrsn.

    METHODS get_domain_text
      IMPORTING iv_value       TYPE clike
      RETURNING VALUE(rv_text) TYPE string.

    METHODS Send_Mails_For_Enquiry
      IMPORTING iv_enqid TYPE zfirfq_quoth-zenqid.

    METHODS authority_check_status
      IMPORTING iv_status            TYPE zzfirfq_enqstatus
                iv_actvt             TYPE activ_auth
      RETURNING VALUE(rv_authorized) TYPE abap_bool.

    METHODS authority_check_bukrs
      IMPORTING iv_bukrs             TYPE bukrs
                iv_actvt             TYPE activ_auth
      RETURNING VALUE(rv_authorized) TYPE abap_bool.

*    METHODS send_rfq_pdf_to_banks
*      IMPORTING iv_enqid TYPE zzfirfq_enqid.


    " ── Nuovo helper: verifica che lo stato sul DB coincida col buffer RAP ──
*    METHODS check_concurrent_modification
*      IMPORTING iv_enqid        TYPE zzfirfq_enqid
*                iv_expected_ts  TYPE timestampl
*      RETURNING VALUE(rv_modified) TYPE abap_bool.

ENDCLASS.

CLASS lhc_rfqheader IMPLEMENTATION.

  METHOD set_status_on_create.

    READ ENTITIES OF zi_fi_rfq_header IN LOCAL MODE
      ENTITY RfqHeader
        FIELDS ( EnqId EnqStatus DirectSubmitted )
        WITH CORRESPONDING #( keys )
      RESULT DATA(lt_header).

    LOOP AT lt_header INTO DATA(ls_header).

      DATA(lv_target_status) = COND zzfirfq_enqstatus(
        WHEN ls_header-DirectSubmitted = abap_true THEN 'SUB'
        ELSE                                            'NEW'
      ).

      MODIFY ENTITIES OF zi_fi_rfq_header IN LOCAL MODE
        ENTITY RfqHeader
          UPDATE FIELDS ( EnqStatus )
          WITH VALUE #( (
            %key      = ls_header-%key
            EnqStatus = lv_target_status
          ) ).



      CHECK ls_header-EnqId IS NOT INITIAL.



      write_history(
        iv_enqid         = ls_header-EnqId
        iv_action        = COND #( WHEN lv_target_status = 'SUB' THEN '2' ELSE '1' )
        iv_status_old    = ''
        iv_status_new    = lv_target_status
        iv_reject_reason = ''
      ).

    ENDLOOP.

  ENDMETHOD.

* HELPER PER RECUPERARE VALORE DOMINIO

  METHOD get_domain_text.

    CHECK iv_value IS NOT INITIAL.

    TRY.
        DATA(lo_elemdescr) = CAST cl_abap_elemdescr(
          cl_abap_typedescr=>describe_by_data( iv_value ) ).

        DATA(lt_values) = lo_elemdescr->get_ddic_fixed_values( p_langu = sy-langu ).

        READ TABLE lt_values ASSIGNING FIELD-SYMBOL(<fs_value>)
          WITH KEY low = iv_value.
        IF sy-subrc = 0.
          rv_text = <fs_value>-ddtext.
        ENDIF.

      CATCH cx_root.
        " valore non trovato o data element non valido -> rv_text resta vuoto
    ENDTRY.

  ENDMETHOD.

*    METHOD check_etag_on_modify.
*  READ ENTITIES OF zi_fi_rfq_header IN LOCAL MODE
*    ENTITY RfqHeader
*      FIELDS ( EnqId LastChangedAt )
*      WITH CORRESPONDING #( keys )
*    RESULT DATA(lt_header).
*
*  LOOP AT lt_header INTO DATA(ls_header).
*    CHECK ls_header-LastChangedAt IS NOT INITIAL.
*
*    SELECT SINGLE laedttm FROM zfirfq_header
*      WHERE zenqid = @ls_header-EnqId
*      INTO @DATA(lv_db_ts).
*
*    " Se il timestamp del FE è diverso da quello sul DB → conflitto
*    IF lv_db_ts <> ls_header-LastChangedAt.
*      APPEND VALUE #(
*        %tky = ls_header-%tky
*        %msg = new_message_with_text(
*                 severity = if_abap_behv_message=>severity-error
*                 text     = |Inquiry { ls_header-EnqId }: modified by another user, please refresh| )
*      ) TO reported-RfqHeader.
*      APPEND VALUE #( %tky = ls_header-%tky ) TO failed-RfqHeader.
*    ENDIF.
*
*  ENDLOOP.
*ENDMETHOD.


  " ═══════════════════════════════════════════════════════════════════════
  " EARLY NUMBERING
  " ═══════════════════════════════════════════════════════════════════════
  METHOD earlynumbering_create.
    " ── Costanti ──────────────────────────────────────────────────────────
*
    DATA: lv_prefix    TYPE nrsobj.  "VALUE 'DSAL'.


    DATA: lv_number            TYPE nrlevel,
          lv_returned_quantity TYPE nrquan,
          lv_returncode        TYPE nrreturn,
          lv_new_id            TYPE zzfirfq_enqid.

    LOOP AT entities INTO DATA(ls_entity).
      " Se EnqId già valorizzato (es. update), skip
      IF ls_entity-EnqId IS NOT INITIAL.
        APPEND CORRESPONDING #( ls_entity ) TO mapped-RfqHeader.
        CONTINUE.
      ENDIF.

      lv_prefix = ls_entity-Beneficiary.

      TRY.
          cl_numberrange_runtime=>number_get(
            EXPORTING
              nr_range_nr       = '01'
              object            = 'ZFIN_LCQUO'
              subobject         = lv_prefix
              toyear            = sy-datum(4)
              quantity          = '1'
            IMPORTING
              number            = lv_number
              returned_quantity = lv_returned_quantity
              returncode        = lv_returncode
          ).

        CATCH cx_nr_object_not_found INTO DATA(lx_1).
          APPEND VALUE #(
            %cid = ls_entity-%cid
            %msg = new_message_with_text(
                     severity = if_abap_behv_message=>severity-error
                     text     = |NR object not found: { lx_1->get_text( ) }| )
          ) TO reported-RfqHeader.
          APPEND VALUE #( %cid = ls_entity-%cid ) TO failed-RfqHeader.
          CONTINUE.

        CATCH cx_nr_interval_not_found INTO DATA(lx_2).
          APPEND VALUE #(
            %cid = ls_entity-%cid
            %msg = new_message_with_text(
                     severity = if_abap_behv_message=>severity-error
                     text     = |NR interval not found: { lx_2->get_text( ) }| )
          ) TO reported-RfqHeader.
          APPEND VALUE #( %cid = ls_entity-%cid ) TO failed-RfqHeader.
          CONTINUE.

        CATCH cx_number_ranges INTO DATA(lx_nr).
          APPEND VALUE #(
            %cid = ls_entity-%cid
            %msg = new_message_with_text(
                     severity = if_abap_behv_message=>severity-error
                     text     = |NR error: { lx_nr->get_text( ) }| )
          ) TO reported-RfqHeader.
          APPEND VALUE #( %cid = ls_entity-%cid ) TO failed-RfqHeader.
          CONTINUE.

      ENDTRY.

      " Costruzione EnqId: 'DSAL' + numero a 5 cifre con zero-padding
      " Risultato: lunghezza totale 9 (DSAL=4 + 5 cifre), es. 'DSAL00001'
      DATA(lv_num_int) = CONV i( lv_number ).
      DATA(lv_num_str) = |{ lv_num_int WIDTH = 5 ALIGN = RIGHT PAD = '0' }|.
      lv_new_id = lv_prefix && lv_num_str.

      APPEND VALUE #(
        %cid  = ls_entity-%cid
        %key  = VALUE #( EnqId = lv_new_id )
        EnqId = lv_new_id
      ) TO mapped-RfqHeader.

    ENDLOOP.
  ENDMETHOD.


  " ═══════════════════════════════════════════════════════════════════════
  " HELPER — verifica modifica concorrente leggendo direttamente dal DB
  " Ritorna abap_true se il record è stato modificato da un altro utente
  " ═══════════════════════════════════════════════════════════════════════
*  METHOD check_concurrent_modification.
*        SELECT SINGLE laedttm
*            FROM zfirfq_header
*            WHERE zenqid = @iv_enqid
*            INTO @DATA(lv_db_ts).
*
*          rv_modified = COND #(
*            WHEN lv_db_ts <> iv_expected_ts THEN abap_true
*            ELSE                                 abap_false
*          ).
*  ENDMETHOD.


  " ═══════════════════════════════════════════════════════════════════════
  " HELPER — scrive una riga in ZFIRFQ_HISTORY
  " ═══════════════════════════════════════════════════════════════════════
  METHOD write_history.
    SELECT MAX( zprnum ) FROM zfirfq_history
      WHERE zenqid = @iv_enqid
      INTO @DATA(lv_max_prnum).

    INSERT zfirfq_history FROM @(
      VALUE zfirfq_history(
        zenqid      = iv_enqid
        zprnum      = lv_max_prnum + 1
        zactions    = iv_action
        zenqstatuso = iv_status_old
        zenqstatusn = iv_status_new
        zrjcrsn     = iv_reject_reason
        zpic        = sy-uname
        dcrdat      = sy-datum
        tcrtim      = sy-uzeit
      )
    ).
  ENDMETHOD.

  " ═══════════════════════════════════════════════════════════════════════
  " HELPER — Authority check ZSTATUS
  " ═══════════════════════════════════════════════════════════════════════

  METHOD authority_check_status.
    AUTHORITY-CHECK OBJECT 'ZSTATUS'
      ID 'ZSTATUS' FIELD iv_status
      ID 'ACTVT'    FIELD iv_actvt.
    rv_authorized = xsdbool( sy-subrc = 0 ).
  ENDMETHOD.

  " ═══════════════════════════════════════════════════════════════════════
  " HELPER — Authority check ZBUKRS
  " ═══════════════════════════════════════════════════════════════════════
  METHOD authority_check_bukrs.

    AUTHORITY-CHECK OBJECT 'ZBUKRS'
      ID 'BUKRS' FIELD iv_bukrs
      ID 'ACTVT' FIELD iv_actvt.

    rv_authorized = xsdbool( sy-subrc = 0 ).

  ENDMETHOD.

  " ═══════════════════════════════════════════════════════════════════════
  " Authority method
  " ═══════════════════════════════════════════════════════════════════════

  METHOD get_instance_authorizations.

    READ ENTITIES OF zi_fi_rfq_header IN LOCAL MODE
      ENTITY RfqHeader
        FIELDS ( EnqId EnqStatus Beneficiary )
        WITH CORRESPONDING #( keys )
      RESULT DATA(lt_header).

    DATA ls_result LIKE LINE OF result.

    LOOP AT lt_header INTO DATA(ls_header).

      CLEAR ls_result.
      ls_result-%tky = ls_header-%tky.

      " ── 1) Check società (ZBUKRS) — blocca tutto se non autorizzato ──────
      IF authority_check_bukrs( iv_bukrs = ls_header-Beneficiary iv_actvt = '02' ) = abap_false.

        ls_result-%update                 = if_abap_behv=>auth-unauthorized.
        ls_result-%delete                 = if_abap_behv=>auth-unauthorized.
        ls_result-%action-SubmitToBanking = if_abap_behv=>auth-unauthorized.
        ls_result-%action-TakeOwnership   = if_abap_behv=>auth-unauthorized.
        ls_result-%action-SendRfqToBanks  = if_abap_behv=>auth-unauthorized.
        ls_result-%action-RejectByBanking = if_abap_behv=>auth-unauthorized.
        ls_result-%action-CloseEnquiry    = if_abap_behv=>auth-unauthorized.
        ls_result-%action-CancelEnquiry   = if_abap_behv=>auth-unauthorized.
        ls_result-%action-CompleteProcess = if_abap_behv=>auth-unauthorized.
        ls_result-%action-OnlySaveHistory = if_abap_behv=>auth-unauthorized.

        APPEND ls_result TO result.
        CONTINUE.

      ENDIF.

      " ── 2) Check stato (ZSTATUS) — granulare, azione per azione ───────────
      ls_result-%update = COND #(
        WHEN authority_check_status( iv_status = ls_header-EnqStatus iv_actvt = '02' ) = abap_true
        THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).

      ls_result-%delete = ls_result-%update.

      ls_result-%action-SubmitToBanking = COND #(
        WHEN ls_header-EnqStatus = 'NEW'
         AND authority_check_status( iv_status = 'NEW' iv_actvt = '02' ) = abap_true
        THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).

      ls_result-%action-TakeOwnership = COND #(
        WHEN ls_header-EnqStatus = 'SUB'
         AND authority_check_status( iv_status = 'SUB' iv_actvt = '02' ) = abap_true
        THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).

      ls_result-%action-SendRfqToBanks = COND #(
        WHEN ( ls_header-EnqStatus = 'PRO' OR ls_header-EnqStatus = 'RFQ' )
         AND authority_check_status( iv_status = ls_header-EnqStatus iv_actvt = '02' ) = abap_true
        THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).

      ls_result-%action-RejectByBanking = COND #(
        WHEN ls_header-EnqStatus = 'PRO'
         AND authority_check_status( iv_status = 'PRO' iv_actvt = '02' ) = abap_true
        THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).

      ls_result-%action-CompleteProcess = COND #(
        WHEN ls_header-EnqStatus = 'RFQ'
         AND authority_check_status( iv_status = 'RFQ' iv_actvt = '02' ) = abap_true
        THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).

      ls_result-%action-CloseEnquiry = COND #(
        WHEN ls_header-EnqStatus <> 'CAN' AND ls_header-EnqStatus <> 'CLO'
         AND authority_check_status( iv_status = ls_header-EnqStatus iv_actvt = '02' ) = abap_true
        THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).

      ls_result-%action-CancelEnquiry = COND #(
        WHEN ls_header-EnqStatus <> 'CAN' AND ls_header-EnqStatus <> 'CLO'
         AND authority_check_status( iv_status = ls_header-EnqStatus iv_actvt = '02' ) = abap_true
        THEN if_abap_behv=>auth-allowed ELSE if_abap_behv=>auth-unauthorized ).

      ls_result-%action-OnlySaveHistory = ls_result-%update.

      APPEND ls_result TO result.

    ENDLOOP.

  ENDMETHOD.

  " ═══════════════════════════════════════════════════════════════════════
  " Validation on SAVE BUKRS
  " ═══════════════════════════════════════════════════════════════════════

  METHOD validate_bukrs.
    READ ENTITIES OF zi_fi_rfq_header IN LOCAL MODE
      ENTITY RfqHeader
        FIELDS ( Beneficiary )
        WITH CORRESPONDING #( keys )
      RESULT DATA(lt_header).

    LOOP AT lt_header INTO DATA(ls_header).
      IF authority_check_bukrs( iv_bukrs = ls_header-Beneficiary iv_actvt = '02' ) = abap_false.
        APPEND VALUE #( %tky = ls_header-%tky ) TO failed-RfqHeader.
        APPEND VALUE #(
          %tky = ls_header-%tky
          %msg = new_message_with_text(
                   severity = if_abap_behv_message=>severity-error
                   text     = |Not authorized for company { ls_header-Beneficiary }| )
        ) TO reported-RfqHeader.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.

  " ═══════════════════════════════════════════════════════════════════════
  " ACTION: SubmitToBanking  —  NEW → SUB  (zactions = '2')
  " ═══════════════════════════════════════════════════════════════════════
  METHOD SubmitToBanking.
    READ ENTITIES OF zi_fi_rfq_header IN LOCAL MODE
      ENTITY RfqHeader
        FIELDS ( EnqId EnqStatus )
        WITH CORRESPONDING #( keys )
      RESULT DATA(lt_header).

    LOOP AT lt_header INTO DATA(ls_header).

      " Valida transizione: solo da NEW
      IF ls_header-EnqStatus <> 'NEW'.
        APPEND VALUE #(
          %tky = ls_header-%tky
          %msg = new_message_with_text(
                   severity = if_abap_behv_message=>severity-error
                   text     = |Inquiry { ls_header-EnqId }: only status NEW (current: { ls_header-EnqStatus })| )
        ) TO reported-RfqHeader.
        APPEND VALUE #( %tky = ls_header-%tky ) TO failed-RfqHeader.
        CONTINUE.
      ENDIF.

      " ── Check concorrenza: lo stato sul DB deve essere ancora NEW ───────
*      IF check_concurrent_modification(
*           iv_enqid           = ls_header-EnqId
*           iv_expected_ts = ls_header-LastChangedAt ) = abap_true.
*        APPEND VALUE #(
*          %tky = ls_header-%tky
*          %msg = new_message_with_text(
*                   severity = if_abap_behv_message=>severity-error
*                   text     = |Inquiry { ls_header-EnqId }: record was modified by another user, please refresh| )
*        ) TO reported-RfqHeader.
*        APPEND VALUE #( %tky = ls_header-%tky ) TO failed-RfqHeader.
*        CONTINUE.
*      ENDIF.

      MODIFY ENTITIES OF zi_fi_rfq_header IN LOCAL MODE
        ENTITY RfqHeader
          UPDATE FIELDS ( EnqStatus )
          WITH VALUE #( ( %tky = ls_header-%tky EnqStatus = 'SUB' ) ).



      write_history(
        iv_enqid         = ls_header-EnqId
        iv_action        = '2'
        iv_status_old    = 'NEW'
        iv_status_new    = 'SUB'
        iv_reject_reason = ''
      ).

    ENDLOOP.

    READ ENTITIES OF zi_fi_rfq_header IN LOCAL MODE
      ENTITY RfqHeader ALL FIELDS
      WITH CORRESPONDING #( keys )
      RESULT DATA(lt_result).
    result = VALUE #( FOR ls IN lt_result ( %tky = ls-%tky %param = ls ) ).
  ENDMETHOD.

  " ═══════════════════════════════════════════════════════════════════════
  " ACTION: TakeOwnership  —  SUB → PRO  (zactions = '3')
  " ═══════════════════════════════════════════════════════════════════════
  METHOD TakeOwnership.
    READ ENTITIES OF zi_fi_rfq_header IN LOCAL MODE
      ENTITY RfqHeader
        FIELDS ( EnqId EnqStatus )
        WITH CORRESPONDING #( keys )
      RESULT DATA(lt_header).

    LOOP AT lt_header INTO DATA(ls_header).

      IF ls_header-EnqStatus <> 'SUB'.
        APPEND VALUE #(
          %tky = ls_header-%tky
          %msg = new_message_with_text(
                   severity = if_abap_behv_message=>severity-error
                   text     = |Inquiry { ls_header-EnqId }: only status SUB (current: { ls_header-EnqStatus })| )
        ) TO reported-RfqHeader.
        APPEND VALUE #( %tky = ls_header-%tky ) TO failed-RfqHeader.
        CONTINUE.
      ENDIF.

      " ── Check concorrenza ───────────────────────────────────────────────
*      IF check_concurrent_modification(
*           iv_enqid           = ls_header-EnqId
*           iv_expected_ts = ls_header-LastChangedAt ) = abap_true.
*        APPEND VALUE #(
*          %tky = ls_header-%tky
*          %msg = new_message_with_text(
*                   severity = if_abap_behv_message=>severity-error
*                   text     = |Inquiry { ls_header-EnqId }: record was modified by another user, please refresh| )
*        ) TO reported-RfqHeader.
*        APPEND VALUE #( %tky = ls_header-%tky ) TO failed-RfqHeader.
*        CONTINUE.
*      ENDIF.

      MODIFY ENTITIES OF zi_fi_rfq_header IN LOCAL MODE
        ENTITY RfqHeader
          UPDATE FIELDS ( EnqStatus PersonInCharge )
          WITH VALUE #( (
            %tky           = ls_header-%tky
            EnqStatus      = 'PRO'
            PersonInCharge = sy-uname
          ) ).



      write_history(
        iv_enqid         = ls_header-EnqId
        iv_action        = '3'
        iv_status_old    = 'SUB'
        iv_status_new    = 'PRO'
        iv_reject_reason = ''
      ).

    ENDLOOP.

    READ ENTITIES OF zi_fi_rfq_header IN LOCAL MODE
      ENTITY RfqHeader ALL FIELDS
      WITH CORRESPONDING #( keys )
      RESULT DATA(lt_result).
    result = VALUE #( FOR ls IN lt_result ( %tky = ls-%tky %param = ls ) ).
  ENDMETHOD.

  " ═══════════════════════════════════════════════════════════════════════
  " ACTION: SendRfqToBanks  —  PRO → RFQ  (zactions = '4')
  " ═══════════════════════════════════════════════════════════════════════
  METHOD SendRfqToBanks.
    READ ENTITIES OF zi_fi_rfq_header IN LOCAL MODE
      ENTITY RfqHeader
        FIELDS ( EnqId EnqStatus )
        WITH CORRESPONDING #( keys )
      RESULT DATA(lt_header).



*    LOOP AT lt_header INTO DATA(ls_header).
    READ TABLE lt_header INDEX 1 INTO DATA(ls_header).
    CHECK sy-subrc = 0.

    IF ls_header-EnqStatus <> 'PRO' AND  ls_header-EnqStatus <> 'RFQ'.
      APPEND VALUE #(
        %tky = ls_header-%tky
        %msg = new_message_with_text(
                 severity = if_abap_behv_message=>severity-error
                 text     = |Inquiry { ls_header-EnqId }: only status PRO/RFQ (current: { ls_header-EnqStatus })| )
      ) TO reported-RfqHeader.
      APPEND VALUE #( %tky = ls_header-%tky ) TO failed-RfqHeader.
*        CONTINUE.
      RETURN.
    ENDIF.

    " check quotation non presenti
    READ ENTITIES OF zi_fi_rfq_header IN LOCAL MODE
      ENTITY RfqHeader BY \_Quotations
        FIELDS ( EnqId QuotNum QuotStatus )
        WITH VALUE #( ( %tky = ls_header-%tky ) )
      RESULT DATA(lt_quoth).

    IF lt_quoth IS INITIAL.
      APPEND VALUE #(
      %tky = ls_header-%tky
      %msg = new_message_with_text(
               severity = if_abap_behv_message=>severity-error
               text     = |No Quotation for Inquiry { ls_header-EnqId }| )
    ) TO reported-RfqHeader.
      APPEND VALUE #( %tky = ls_header-%tky ) TO failed-RfqHeader.
*        CONTINUE.
      RETURN.


    ENDIF.

    " ── Check concorrenza ───────────────────────────────────────────────
*      IF check_concurrent_modification(
*           iv_enqid           = ls_header-EnqId
*           iv_expected_ts = ls_header-LastChangedAt ) = abap_true.
*        APPEND VALUE #(
*          %tky = ls_header-%tky
*          %msg = new_message_with_text(
*                   severity = if_abap_behv_message=>severity-error
*                   text     = |Inquiry { ls_header-EnqId }: record was modified by another user, please refresh| )
*        ) TO reported-RfqHeader.
*        APPEND VALUE #( %tky = ls_header-%tky ) TO failed-RfqHeader.
*        CONTINUE.
*      ENDIF.

    IF ls_header-EnqStatus = 'PRO'.
      SELECT COUNT(*) FROM zfirfq_issb
        WHERE zenqid = @ls_header-EnqId
        INTO @DATA(lv_bank_count).

      IF lv_bank_count = 0.
        APPEND VALUE #(
          %tky = ls_header-%tky
          %msg = new_message_with_text(
                   severity = if_abap_behv_message=>severity-error
                   text     = |Inquiry { ls_header-EnqId }: no issuing bank associated| )
        ) TO reported-RfqHeader.
        APPEND VALUE #( %tky = ls_header-%tky ) TO failed-RfqHeader.
*          CONTINUE.
        RETURN.
      ENDIF.
*         Aggiorno header PRO → RFQ
      MODIFY ENTITIES OF zi_fi_rfq_header IN LOCAL MODE
        ENTITY RfqHeader
          UPDATE FIELDS ( EnqStatus )
          WITH VALUE #( ( %tky = ls_header-%tky EnqStatus = 'RFQ' ) ).

*         Aggiorno tutte le quotations NEW → AWA per questo inquiry
      UPDATE zfirfq_quoth
         SET zquotstatus = 'AWA'
         WHERE zenqid      = @ls_header-EnqId
         AND zquotstatus = 'NEW'.



      write_history(
        iv_enqid         = ls_header-EnqId
        iv_action        = '4'
        iv_status_old    = 'PRO'
        iv_status_new    = 'RFQ'
        iv_reject_reason = ''
      ).
    ELSEIF ls_header-EnqStatus = 'RFQ'.

*          Aggiorno tutte le quotations NEW → AWA per questo inquiry
      UPDATE zfirfq_quoth
         SET zquotstatus = 'AWA'
         WHERE zenqid      = @ls_header-EnqId
         AND zquotstatus = 'NEW'.

      write_history(
        iv_enqid         = ls_header-EnqId
        iv_action        = '4'
        iv_status_old    = 'RFQ'
        iv_status_new    = 'RFQ'
        iv_reject_reason = ''
      ).

    ENDIF.
*        richiamo il metodo di appoggio
*         send_rfq_pdf_to_banks( iv_enqid = ls_header-EnqId ).

*    ENDLOOP.

    READ ENTITIES OF zi_fi_rfq_header IN LOCAL MODE
      ENTITY RfqHeader ALL FIELDS
      WITH CORRESPONDING #( keys )
      RESULT DATA(lt_result).
    result = VALUE #( FOR ls IN lt_result ( %tky = ls-%tky %param = ls ) ).
  ENDMETHOD.

  " ═══════════════════════════════════════════════════════════════════════
  " ACTION: CompleteProcess  —  RFQ → COM  (zactions = '5') OR RFQ → CLO  (zactions = '6')
  " ═══════════════════════════════════════════════════════════════════════
  METHOD CompleteProcess.

    READ ENTITIES OF zi_fi_rfq_header IN LOCAL MODE
    ENTITY RfqHeader
      FIELDS ( EnqId EnqStatus )
      WITH CORRESPONDING #( keys )
    RESULT DATA(lt_header).

    READ TABLE lt_header INDEX 1 INTO DATA(ls_header).
    CHECK sy-subrc = 0.

    IF ls_header-EnqStatus <> 'RFQ'.
      APPEND VALUE #(
        %tky = ls_header-%tky
        %msg = new_message_with_text(
                 severity = if_abap_behv_message=>severity-error
                 text     = |Inquiry { ls_header-EnqId }: only status RFQ (current: { ls_header-EnqStatus })| )
      ) TO reported-RfqHeader.
      APPEND VALUE #( %tky = ls_header-%tky ) TO failed-RfqHeader.
      RETURN.
    ENDIF.

    SELECT SINGLE zenqid FROM zfirfq_quoth
      WHERE zenqid = @ls_header-EnqId
      INTO @DATA(lv_exists).

    IF sy-subrc <> 0.
      APPEND VALUE #(
        %tky = ls_header-%tky
        %msg = new_message_with_text(
                 severity = if_abap_behv_message=>severity-error
                 text     = |Inquiry { ls_header-EnqId }: no quotations found| )
      ) TO reported-RfqHeader.
      APPEND VALUE #( %tky = ls_header-%tky ) TO failed-RfqHeader.
      RETURN.
    ENDIF.

    SELECT SINGLE zenqid FROM zfirfq_quoth
      WHERE zenqid      = @ls_header-EnqId
        AND zquotstatus = 'CHO'
      INTO @DATA(lv_not_dec).

    IF sy-subrc = 0.
*    not all quotations are declined or rejected or not chosed
      MODIFY ENTITIES OF zi_fi_rfq_header IN LOCAL MODE
      ENTITY RfqHeader
        UPDATE FIELDS ( EnqStatus )
        WITH VALUE #( ( %tky = ls_header-%tky EnqStatus = 'COM' ) ).

*      Aggiorno tutte le quotations automanticamente

      " Leggo le righe da aggiornare
      SELECT * FROM zfirfq_quoth
        INTO TABLE @DATA(lt_update)
        WHERE zenqid = @ls_header-EnqId
        AND zquotstatus = 'AWA'.
*          AND zquotstatus IN ('AWA', 'QUO', 'NEW').

      " Mappo i nuovi stati
      LOOP AT lt_update INTO DATA(ls_update).
        ls_update-zquotstatus = SWITCH #( ls_update-zquotstatus
          WHEN 'AWA' THEN 'NQU' ).
*          WHEN 'QUO' THEN 'DEC'
*          WHEN 'NEW' THEN 'CAN' ).
        MODIFY lt_update FROM ls_update.
      ENDLOOP.

      "UPDATE RECORD
      UPDATE zfirfq_quoth FROM TABLE lt_update.


      write_history(
        iv_enqid         = ls_header-EnqId
        iv_action        = '5'
        iv_status_old    = 'RFQ'
        iv_status_new    = 'COM'
        iv_reject_reason = ''
      ).

      Send_Mails_For_Enquiry( iv_enqid = ls_header-EnqId ).

      READ ENTITIES OF zi_fi_rfq_header IN LOCAL MODE
        ENTITY RfqHeader ALL FIELDS
        WITH CORRESPONDING #( keys )
        RESULT DATA(lt_result).
      result = VALUE #( FOR ls IN lt_result ( %tky = ls-%tky %param = ls ) ).

    ELSE.

      MODIFY ENTITIES OF zi_fi_rfq_header IN LOCAL MODE
     ENTITY RfqHeader
       UPDATE FIELDS ( EnqStatus )
       WITH VALUE #( ( %tky = ls_header-%tky EnqStatus = 'CLO' ) ).

*      Aggiorno tutte le quotations automanticamente

      " Leggo le righe da aggiornare
      SELECT * FROM zfirfq_quoth
        INTO TABLE @DATA(lt_update2)
        WHERE zenqid = @ls_header-EnqId
         AND zquotstatus = 'AWA'.
*          AND zquotstatus IN ('AWA', 'QUO', 'NEW').

      " Mappo i nuovi stati
      LOOP AT lt_update2 INTO DATA(ls_update2).
        ls_update2-zquotstatus = SWITCH #( ls_update2-zquotstatus
          WHEN 'AWA' THEN 'NQU' ).
*          WHEN 'QUO' THEN 'DEC'
*          WHEN 'NEW' THEN 'CAN' ).
        MODIFY lt_update2 FROM ls_update2.
      ENDLOOP.

      "UPDATE RECORD
      UPDATE zfirfq_quoth FROM TABLE lt_update2.

      write_history(
        iv_enqid         = ls_header-EnqId
        iv_action        = '6'
        iv_status_old    = 'RFQ'
        iv_status_new    = 'CLO'
        iv_reject_reason = ''
      ).

      Send_Mails_For_Enquiry( iv_enqid = ls_header-EnqId ).

      READ ENTITIES OF zi_fi_rfq_header IN LOCAL MODE
        ENTITY RfqHeader ALL FIELDS
        WITH CORRESPONDING #( keys )
        RESULT DATA(lt_result2).
      result = VALUE #( FOR ls IN lt_result2 ( %tky = ls-%tky %param = ls ) ).

    ENDIF.

  ENDMETHOD.
  " ═══════════════════════════════════════════════════════════════════════
  " ACTION: CloseEnquiry  —  PRO OR RFQ  → CLO  (zactions = '6')
  " ═══════════════════════════════════════════════════════════════════════
  METHOD CloseEnquiry.
    READ ENTITIES OF zi_fi_rfq_header IN LOCAL MODE
      ENTITY RfqHeader
        FIELDS ( EnqId EnqStatus )
        WITH CORRESPONDING #( keys )
      RESULT DATA(lt_header).

    LOOP AT lt_header INTO DATA(ls_header).

      IF ls_header-EnqStatus = 'CAN' OR ls_header-EnqStatus = 'CLO'.
        APPEND VALUE #(
          %tky = ls_header-%tky
          %msg = new_message_with_text(
                   severity = if_abap_behv_message=>severity-error
                   text     = |Inquiry { ls_header-EnqId }: already cancelled or closed| )
        ) TO reported-RfqHeader.
        APPEND VALUE #( %tky = ls_header-%tky ) TO failed-RfqHeader.
        CONTINUE.
      ENDIF.

      " ── Check concorrenza: stato DB deve coincidere col buffer ──────────
*      IF check_concurrent_modification(
*           iv_enqid           = ls_header-EnqId
*           iv_expected_ts = ls_header-LastChangedAt ) = abap_true.
*        APPEND VALUE #(
*          %tky = ls_header-%tky
*          %msg = new_message_with_text(
*                   severity = if_abap_behv_message=>severity-error
*                   text     = |Inquiry { ls_header-EnqId }: record was modified by another user, please refresh| )
*        ) TO reported-RfqHeader.
*        APPEND VALUE #( %tky = ls_header-%tky ) TO failed-RfqHeader.
*        CONTINUE.
*      ENDIF.

      DATA(lv_old_status) = ls_header-EnqStatus.

      MODIFY ENTITIES OF zi_fi_rfq_header IN LOCAL MODE
        ENTITY RfqHeader
          UPDATE FIELDS ( EnqStatus )
          WITH VALUE #( ( %tky = ls_header-%tky EnqStatus = 'CLO' ) ).



      write_history(
        iv_enqid         = ls_header-EnqId
        iv_action        = '6'
        iv_status_old    = lv_old_status
        iv_status_new    = 'CLO'
        iv_reject_reason = ''
      ).

    ENDLOOP.

    READ ENTITIES OF zi_fi_rfq_header IN LOCAL MODE
      ENTITY RfqHeader ALL FIELDS
      WITH CORRESPONDING #( keys )
      RESULT DATA(lt_result).
    result = VALUE #( FOR ls IN lt_result ( %tky = ls-%tky %param = ls ) ).
  ENDMETHOD.


  " ═══════════════════════════════════════════════════════════════════════
  " ACTION: CancelEnquiry  —  any → CAN  (zactions = '7')
  " ═══════════════════════════════════════════════════════════════════════
  METHOD CancelEnquiry.
    READ ENTITIES OF zi_fi_rfq_header IN LOCAL MODE
      ENTITY RfqHeader
        FIELDS ( EnqId EnqStatus )
        WITH CORRESPONDING #( keys )
      RESULT DATA(lt_header).

    LOOP AT lt_header INTO DATA(ls_header).

      IF ls_header-EnqStatus = 'CAN' OR ls_header-EnqStatus = 'CLO'.
        APPEND VALUE #(
          %tky = ls_header-%tky
          %msg = new_message_with_text(
                   severity = if_abap_behv_message=>severity-error
                   text     = |Inquiry { ls_header-EnqId }: already cancelled or closed| )
        ) TO reported-RfqHeader.
        APPEND VALUE #( %tky = ls_header-%tky ) TO failed-RfqHeader.
        CONTINUE.
      ENDIF.

      " ── Check concorrenza: stato DB deve coincidere col buffer ──────────
*      IF check_concurrent_modification(
*           iv_enqid           = ls_header-EnqId
*           iv_expected_ts = ls_header-LastChangedAt ) = abap_true.
*        APPEND VALUE #(
*          %tky = ls_header-%tky
*          %msg = new_message_with_text(
*                   severity = if_abap_behv_message=>severity-error
*                   text     = |Inquiry { ls_header-EnqId }: record was modified by another user, please refresh| )
*        ) TO reported-RfqHeader.
*        APPEND VALUE #( %tky = ls_header-%tky ) TO failed-RfqHeader.
*        CONTINUE.
*      ENDIF.

      DATA(lv_old_status) = ls_header-EnqStatus.

      MODIFY ENTITIES OF zi_fi_rfq_header IN LOCAL MODE
        ENTITY RfqHeader
          UPDATE FIELDS ( EnqStatus )
          WITH VALUE #( ( %tky = ls_header-%tky EnqStatus = 'CAN' ) ).



      write_history(
        iv_enqid         = ls_header-EnqId
        iv_action        = '7'
        iv_status_old    = lv_old_status
        iv_status_new    = 'CAN'
        iv_reject_reason = ''
      ).

    ENDLOOP.

    READ ENTITIES OF zi_fi_rfq_header IN LOCAL MODE
      ENTITY RfqHeader ALL FIELDS
      WITH CORRESPONDING #( keys )
      RESULT DATA(lt_result).
    result = VALUE #( FOR ls IN lt_result ( %tky = ls-%tky %param = ls ) ).
  ENDMETHOD.

  " ═══════════════════════════════════════════════════════════════════════
  " ACTION: RejectByBanking  —  PRO → NEW  (zactions = '1')
  " ═══════════════════════════════════════════════════════════════════════
  METHOD RejectByBanking.
    DATA lv_rej_reason TYPE zzfirfq_rejrsn.

    READ ENTITIES OF zi_fi_rfq_header IN LOCAL MODE
      ENTITY RfqHeader
        FIELDS ( EnqId EnqStatus )
        WITH CORRESPONDING #( keys )
      RESULT DATA(lt_header).

    LOOP AT keys INTO DATA(ls_key).
      DATA(ls_param) = ls_key-%param.
    ENDLOOP.

    lv_rej_reason = ls_param-RejectReason.

    LOOP AT lt_header INTO DATA(ls_header).

      IF ls_header-EnqStatus <> 'PRO'.
        APPEND VALUE #(
          %tky = ls_header-%tky
          %msg = new_message_with_text(
                   severity = if_abap_behv_message=>severity-error
                   text     = |Inquiry { ls_header-EnqId }: only status PRO (current: { ls_header-EnqStatus })| )
        ) TO reported-RfqHeader.
        APPEND VALUE #( %tky = ls_header-%tky ) TO failed-RfqHeader.
        CONTINUE.
      ENDIF.

      " ── Check concorrenza ───────────────────────────────────────────────
*      IF check_concurrent_modification(
*           iv_enqid           = ls_header-EnqId
*           iv_expected_ts = ls_header-LastChangedAt ) = abap_true.
*        APPEND VALUE #(
*          %tky = ls_header-%tky
*          %msg = new_message_with_text(
*                   severity = if_abap_behv_message=>severity-error
*                   text     = |Inquiry { ls_header-EnqId }: record was modified by another user, please refresh| )
*        ) TO reported-RfqHeader.
*        APPEND VALUE #( %tky = ls_header-%tky ) TO failed-RfqHeader.
*        CONTINUE.
*      ENDIF.

      MODIFY ENTITIES OF zi_fi_rfq_header IN LOCAL MODE
        ENTITY RfqHeader
          UPDATE FIELDS ( EnqStatus )
          WITH VALUE #( ( %tky = ls_header-%tky EnqStatus = 'NEW' ) ).



      write_history(
        iv_enqid         = ls_header-EnqId
        iv_action        = '1'
        iv_status_old    = 'PRO'
        iv_status_new    = 'NEW'
        iv_reject_reason = lv_rej_reason
      ).

    ENDLOOP.

    READ ENTITIES OF zi_fi_rfq_header IN LOCAL MODE
      ENTITY RfqHeader ALL FIELDS
      WITH CORRESPONDING #( keys )
      RESULT DATA(lt_result).
    result = VALUE #( FOR ls IN lt_result ( %tky = ls-%tky %param = ls ) ).
  ENDMETHOD.
  " ── NOTIFICATION METHOD  ───────────────────────────────────────────────
  METHOD SendNotification.


*    DATA: lv_title    TYPE string,
*          lv_subtitle TYPE string.
*
*    READ ENTITIES OF zi_fi_rfq_header IN LOCAL MODE
*        ENTITY RfqHeader
*          FIELDS ( EnqId EnqStatus )
*          WITH CORRESPONDING #( keys )
*        RESULT DATA(lt_header).
*
*    LOOP AT keys INTO DATA(ls_key).
*      DATA(ls_param) = ls_key-%param.
*    ENDLOOP.
*
*    SELECT usr21~bname,
*           adcp~department
*      FROM usr21
*      INNER JOIN adcp ON adcp~addrnumber = usr21~addrnumber
*                      AND adcp~persnumber = usr21~persnumber
*      INTO TABLE @DATA(lt_users_dept)
*      WHERE adcp~department = @ls_param-Team.
*
*    LOOP AT lt_header INTO DATA(ls_header).
*      TRY.
**          lv_title = text-001.
**          lv_title = |Test Creation record { ls_header-EnqId }|.
**          lv_subtitle = |Subtitile test Creation record { ls_header-EnqId }|.
*          lv_title = |{ ls_param-String1 } { ls_header-EnqId }|.
*          lv_subtitle = |{ ls_param-String2 } { ls_header-EnqId } { ls_param-String3 }|.
*
*          DATA(lo_notify) = NEW zcl_fi_lcquot_notify( ).
*          lo_notify->send_notification(
*            iv_recipient = ls_param-Recipient
*            iv_title     = lv_title
*            iv_subtitle  = lv_subtitle
*            iv_priority = 'LOW'
*            iv_inquiry = ls_header-EnqId
*          ).
*        CATCH cx_root.
*          " Swallow errors - notification must not block
*      ENDTRY.
*    ENDLOOP.
*
    DATA: lv_title     TYPE string,
          lv_subtitle  TYPE string,
          lv_bukrs     TYPE bukrs,
          lv_agr_name  TYPE agr_name,
          lv_requestor TYPE  zzfirfq_requestor.

    READ ENTITIES OF zi_fi_rfq_header IN LOCAL MODE
        ENTITY RfqHeader
          FIELDS ( EnqId EnqStatus Beneficiary Requestor )
          WITH CORRESPONDING #( keys )
        RESULT DATA(lt_header).

    LOOP AT keys INTO DATA(ls_key).
      DATA(ls_param) = ls_key-%param.
    ENDLOOP.

*    SELECT usr21~bname
*      FROM usr21
*      INNER JOIN adcp ON adcp~addrnumber = usr21~addrnumber
*                      AND adcp~persnumber = usr21~persnumber
*      INTO TABLE @DATA(lt_users_dept)
*      WHERE adcp~department = @ls_param-Team.
*
*    DATA(lt_recipients) = VALUE zcl_fi_lcquot_notify=>ty_t_recipients( ).
*    LOOP AT lt_users_dept INTO DATA(ls_user).
*      APPEND ls_user-bname TO lt_recipients.
*    ENDLOOP.



    " --- Bukrs prelevata dal Beneficiary del primo record di lt_header ---
    IF lt_header IS NOT INITIAL.
      lv_bukrs = lt_header[ 1 ]-Beneficiary.
      lv_requestor = lt_header[ 1 ]-Requestor.
    ENDIF.

    " --- Costruzione dinamica del nome ruolo in base al Team ricevuto dal FE ---

    CLEAR lv_agr_name.

    CASE ls_param-Team.
      WHEN 'Administration'.
        lv_agr_name = 'ZD_XXXX_XXXX_LC_QUOTATION_ADM'.
      WHEN 'Banking'.
        lv_agr_name = 'ZD_XXXX_XXXX_LC_QUOTATION'.
      WHEN OTHERS.
        " Team non gestito: nessuna estrazione utenze
    ENDCASE.

    DATA(lt_recipients) = VALUE zcl_fi_lcquot_notify=>ty_t_recipients( ).

    IF lv_agr_name EQ 'ZD_XXXX_XXXX_LC_QUOTATION' AND lv_bukrs IS NOT INITIAL.
      " Sostituisco solo il PRIMO segmento XXXX con la bukrs (4 caratteri)
      REPLACE FIRST OCCURRENCE OF 'XXXX' IN lv_agr_name WITH lv_bukrs.

      " --- Estrazione utenze assegnate al ruolo (con validità temporale) ---
      SELECT uname
        FROM agr_users
        INTO TABLE @DATA(lt_users_role)
        WHERE agr_name = @lv_agr_name
          AND from_dat <= @sy-datum
          AND to_dat   >= @sy-datum.

      LOOP AT lt_users_role INTO DATA(ls_user_role).
        APPEND ls_user_role-uname TO lt_recipients.
      ENDLOOP.
    ENDIF.

    IF lv_agr_name EQ 'ZD_XXXX_XXXX_LC_QUOTATION_ADM' AND lv_bukrs IS NOT INITIAL.


      " --- 1° accesso: estrazione ZZH_OID per company_code + requestor ---
      SELECT zzh_oid
        FROM zscm_tc_deptappr
        INTO TABLE @DATA(lt_oid_range)
        WHERE company_code = @lv_bukrs
          AND bname        = @lv_requestor.

      IF sy-subrc = 0.
        SORT lt_oid_range BY zzh_oid.
        DELETE ADJACENT DUPLICATES FROM lt_oid_range COMPARING zzh_oid.

        " --- 2° accesso: estrazione BNAME per company_code + range di ZZH_OID ---
        SELECT bname
          FROM zscm_tc_deptappr
          INTO TABLE @DATA(lt_recipients_deptappr)
          FOR ALL ENTRIES IN @lt_oid_range
          WHERE company_code = @lv_bukrs
            AND zzh_oid      = @lt_oid_range-zzh_oid.

        IF sy-subrc = 0.
          SORT lt_recipients_deptappr BY bname.
          DELETE ADJACENT DUPLICATES FROM lt_recipients_deptappr COMPARING bname.

          LOOP AT lt_recipients_deptappr INTO DATA(ls_recipient_deptappr).
            APPEND ls_recipient_deptappr-bname TO lt_recipients.
          ENDLOOP.
        ENDIF.
      ENDIF.
    ENDIF.


    IF lt_recipients IS NOT INITIAL.
      LOOP AT lt_header INTO DATA(ls_header).
        TRY.
            lv_title    = |{ ls_param-String1 } { ls_header-EnqId }|.
            lv_subtitle = |{ ls_param-String2 } { ls_header-EnqId } { ls_param-String3 }|.

            DATA(lo_notify) = NEW zcl_fi_lcquot_notify( ).
            lo_notify->send_notification(
              it_recipient = lt_recipients
              iv_title     = lv_title
              iv_subtitle  = lv_subtitle
              iv_priority  = 'LOW'
              iv_inquiry   = ls_header-EnqId
            ).
          CATCH cx_root.
            " Swallow errors - notification must not block
        ENDTRY.
      ENDLOOP.
    ENDIF.

  ENDMETHOD.


  METHOD OnlySaveHistory.

    READ ENTITIES OF zi_fi_rfq_header IN LOCAL MODE
      ENTITY RfqHeader
        FIELDS ( EnqId EnqStatus )
        WITH CORRESPONDING #( keys )
      RESULT DATA(lt_header).

    LOOP AT lt_header INTO DATA(ls_header).

      write_history(
        iv_enqid         = ls_header-EnqId
        iv_action        = '8'
        iv_status_old    = ls_header-EnqStatus
        iv_status_new    = ls_header-EnqStatus
        iv_reject_reason = ''
      ).

    ENDLOOP.

    READ ENTITIES OF zi_fi_rfq_header IN LOCAL MODE
      ENTITY RfqHeader ALL FIELDS
      WITH CORRESPONDING #( keys )
      RESULT DATA(lt_result).
    result = VALUE #( FOR ls IN lt_result ( %tky = ls-%tky %param = ls ) ).
  ENDMETHOD.

  METHOD sendpdftobank.

    DATA: gs_head       TYPE zsfi_ifmlc_head,
          gt_issue      TYPE zsfi_ifmlc_issu_t,
          gs_issue      TYPE zsfi_ifmlc_issu,
          gt_so         TYPE zsfi_ifmlc_so_t,
          gs_so         TYPE zsfi_ifmlc_so,
          gt_quot_block TYPE zsfi_ifmlc_quot_block_t,
          gs_quot_block TYPE zsfi_ifmlc_quot_block,
          gs_quot       TYPE zsfi_ifmlc_quot,
          gs_conf       TYPE zsfi_ifmlc_comm,
          gs_deff       TYPE zsfi_ifmlc_comm,
          gs_disc       TYPE zsfi_ifmlc_disc.

    DATA: lt_values TYPE STANDARD TABLE OF dd07v WITH EMPTY KEY.

    " ------------------------------------------------------------------
    " Lettura chiave da RAP
    " ------------------------------------------------------------------
    READ ENTITIES OF zi_fi_rfq_header IN LOCAL MODE
      ENTITY RfqHeader
        ALL FIELDS
        WITH CORRESPONDING #( keys )
      RESULT DATA(lt_header).

    READ TABLE lt_header INDEX 1 INTO DATA(ls_header).
    CHECK sy-subrc = 0.

    " ------------------------------------------------------------------
    " Lettura dati da RAP / DB
    " ------------------------------------------------------------------
    READ ENTITIES OF zi_fi_rfq_header IN LOCAL MODE
      ENTITY RfqHeader BY \_SalesOrders
        ALL FIELDS
        WITH VALUE #( ( %tky = ls_header-%tky ) )
      RESULT DATA(lt_so).

    READ ENTITIES OF zi_fi_rfq_header IN LOCAL MODE
      ENTITY RfqHeader BY \_IssuingBanks
        ALL FIELDS
        WITH VALUE #( ( %tky = ls_header-%tky ) )
      RESULT DATA(lt_issb).

    READ ENTITIES OF zi_fi_rfq_header IN LOCAL MODE
      ENTITY RfqHeader BY \_Quotations
        ALL FIELDS
        WITH VALUE #( ( %tky = ls_header-%tky ) )
      RESULT DATA(lt_quot_all).

    " Items dal DB (matching su lt_quot_all)
    DATA lt_quoti_all TYPE STANDARD TABLE OF zfirfq_quoti WITH EMPTY KEY.

    IF lt_quot_all IS NOT INITIAL.
      SELECT *
        FROM zfirfq_quoti
        INTO TABLE @lt_quoti_all
        FOR ALL ENTRIES IN @lt_quot_all
        WHERE zenqid  = @lt_quot_all-enqid
          AND zquotnum = @lt_quot_all-quotnum.
    ENDIF.

    SORT lt_quoti_all BY zenqid zquotnum zchartyp.

    " Elenco banche distinte
    DATA lt_banks TYPE SORTED TABLE OF zfirfq_quoth WITH UNIQUE KEY zconfbank.

    LOOP AT lt_quot_all INTO DATA(ls_q).
      DATA(ls_quoth_tmp) = VALUE zfirfq_quoth( zconfbank = ls_q-ConfirmingBankCode ).
      TRY.
          INSERT ls_quoth_tmp INTO TABLE lt_banks.
        CATCH cx_sy_itab_duplicate_key.
      ENDTRY.
    ENDLOOP.

    " ------------------------------------------------------------------
    " Lettura Body, Subject, To e CC da ls_param
    " ------------------------------------------------------------------
    DATA: lt_body    TYPE soli_tab,
          lv_body    TYPE string,
          lv_subject TYPE so_obj_des,
          lt_to      TYPE string_table,
          lt_cc      TYPE string_table.

    LOOP AT keys INTO DATA(ls_key).
      DATA(ls_param) = ls_key-%param.
    ENDLOOP.

    lv_body = ls_param-Body.
    lv_subject = ls_param-Subject.

    DATA(lv_operation) = ls_param-Operation.

    IF lv_operation = '01'.

      " Logica per i TO
      SPLIT ls_param-toMail AT ';' INTO TABLE DATA(lt_split_to).
      LOOP AT lt_split_to INTO DATA(lv_mail_to).

        CONDENSE lv_mail_to.

        IF lv_mail_to IS NOT INITIAL.

          APPEND lv_mail_to TO lt_to.

        ENDIF.

      ENDLOOP.

      " Logica per i CC
      SPLIT ls_param-ccMail AT ';' INTO TABLE DATA(lt_split_cc).
      LOOP AT lt_split_cc INTO DATA(lv_mail_cc).

        CONDENSE lv_mail_cc.

        IF lv_mail_cc IS NOT INITIAL.

          APPEND lv_mail_cc TO lt_cc.

        ENDIF.

      ENDLOOP.

    ENDIF.

    " Split su newline per il Body
    SPLIT lv_body AT cl_abap_char_utilities=>newline
      INTO TABLE DATA(lt_lines).

    LOOP AT lt_lines INTO DATA(lv_line).
      APPEND VALUE soli( line = lv_line ) TO lt_body.
    ENDLOOP.

    " ------------------------------------------------------------------
    " Mappatura header principale (da ls_header RAP)
    " ------------------------------------------------------------------
    CLEAR gs_head.
    gs_head-inquiry_id       = ls_header-EnqId.
    gs_head-request_person   = ls_header-RequestorFullName.
    gs_head-person_charge    = ls_header-PersonInChargeFullName.

    SELECT SINGLE butxt
    FROM t001
    WHERE bukrs = @ls_header-Beneficiary
    INTO @gs_head-beneficiary .

    gs_head-customer         = ls_header-Customer && ' ' && ls_header-CustomerCountryMan.
    gs_head-tolerance_n      = ls_header-NegTolerance.
    gs_head-tolerance_p      = ls_header-PosTolerance.
    gs_head-fob_place        = ls_header-FobPlace.
    gs_head-destinations     = ls_header-DestCountryName.
    gs_head-description      = ls_header-DeliveryTerms3.
    gs_head-latest_ship_date = ls_header-DeliveryDate.
    gs_head-expiry_date      = ls_header-ExpiryDate.
    gs_head-payment_terms    = ls_header-PaymentTermsText.
    gs_head-expected_date    = ls_header-ExpIssDate.
    gs_head-amount           = ls_header-Amount.
    gs_head-currency         = ls_header-Currency.

    gs_head-confirmation_charges = get_domain_text(
      iv_value        =  ls_header-ConfChargePayer ).

    gs_head-discount_charges = get_domain_text(
      iv_value        = ls_header-DiscChargePayer ).

    gs_head-deferred_payer = get_domain_text(
      iv_value        = ls_header-DefChargePayer ).

    gs_head-prod_type = ls_header-ProdTyp.
    gs_head-bukrs = ls_header-Beneficiary.
    gs_head-issuing_country = ls_header-DestCountryBankName.
    gs_head-issuing_country_code = ls_header-DestCountryBank.

    " Sales Orders -> IT_SO
    CLEAR gt_so.
    LOOP AT lt_so INTO DATA(ls_so).
      CLEAR gs_so.
      gs_so-so = ls_so-SalesOrder.
      APPEND gs_so TO gt_so.
    ENDLOOP.

    " Issuing bank -> IT_ISSUE
    CLEAR gt_issue.
    LOOP AT lt_issb INTO DATA(ls_issb).
      CLEAR gs_issue.
      gs_issue-issuing_bank_name    = ls_issb-BankName.
      gs_issue-issuing_bank_country = ls_issb-City.
      APPEND gs_issue TO gt_issue.
    ENDLOOP.

    SORT lt_quoti_all BY zenqid zquotnum.

    " ------------------------------------------------------------------
    " Ciclo per ogni banca distinta
    " ------------------------------------------------------------------
    LOOP AT lt_banks INTO DATA(ls_bank).

      DATA lt_quot_bank LIKE lt_quot_all.
      CLEAR lt_quot_bank.

      LOOP AT lt_quot_all INTO DATA(ls_qh) WHERE ConfirmingBankCode = ls_bank-zconfbank.
        APPEND ls_qh TO lt_quot_bank.
      ENDLOOP.

      IF lt_quot_bank IS INITIAL.
        CONTINUE.
      ENDIF.

      SORT lt_quot_bank BY QuotNum.

      " Inizializza blocchi
      CLEAR gt_quot_block.
      CLEAR gs_quot_block.
      CLEAR gs_quot_block-quot.
      CLEAR gs_quot_block-conf.
      CLEAR gs_quot_block-defe.
      CLEAR gs_quot_block-disc.

      DATA(lv_prev_quotnum) = ''.

      " LOOP sulle quotation della banca corrente
      LOOP AT lt_quot_bank INTO DATA(ls_qh2).

        IF lv_prev_quotnum IS INITIAL OR lv_prev_quotnum <> ls_qh2-QuotNum.
          IF lv_prev_quotnum IS NOT INITIAL AND gs_quot_block-quot IS NOT INITIAL.
            APPEND gs_quot_block TO gt_quot_block.
          ENDIF.

          CLEAR gs_quot_block.
          CLEAR gs_quot_block-quot.
          CLEAR gs_quot_block-conf.
          CLEAR gs_quot_block-defe.
          CLEAR gs_quot_block-disc.
          gs_quot_block-quotation_id = ls_qh2-QuotNum.
          lv_prev_quotnum = ls_qh2-QuotNum.
        ENDIF.

        CLEAR gs_quot.
        gs_quot-quotation_id = ls_qh2-QuotNum.

        gs_quot-status = get_domain_text(
            iv_value        =  ls_qh2-QuotStatus ).

        gs_quot-issuing_bank    = ls_qh2-IssuingBankName.
        gs_quot-advising_bank   = ls_qh2-AdvisingBankName.
        gs_quot-confirming_bank = ls_qh2-ConfirmingBankName.
        gs_quot-currency        = ls_qh2-Currency.
        gs_quot-notes           = ls_qh2-Notes.

        APPEND gs_quot TO gs_quot_block-quot.

        " --- chartyp = 2 -> Commitment (gs_conf)
        CLEAR gs_conf.
        READ TABLE lt_quoti_all ASSIGNING FIELD-SYMBOL(<fs_commit>)
          WITH KEY zenqid = ls_qh2-EnqId zquotnum = ls_qh2-QuotNum zchartyp = '2'
          BINARY SEARCH.

        IF sy-subrc = 0.
          gs_conf-quotation_id = ls_qh2-QuotNum.
          gs_conf-rate         = <fs_commit>-pkond.

          gs_conf-period_type = get_domain_text(
             iv_value        =  <fs_commit>-zpertyp ).

          gs_conf-min_amount  = <fs_commit>-zminamt.
          gs_conf-max_amount  = <fs_commit>-zmaxamt.
          gs_conf-flat_amount = <fs_commit>-zflatamt.
          gs_conf-waers       = <fs_commit>-waers.
          gs_conf-notes       = <fs_commit>-znotes.
          APPEND gs_conf TO gs_quot_block-conf.
        ENDIF.

        UNASSIGN <fs_commit>.

        " --- chartyp = 3 -> Deferred (gs_deff)
        CLEAR gs_deff.
        READ TABLE lt_quoti_all ASSIGNING FIELD-SYMBOL(<fs_deferred>)
          WITH KEY zenqid = ls_qh2-EnqId zquotnum = ls_qh2-QuotNum zchartyp = '3'
          BINARY SEARCH.

        IF sy-subrc = 0.
          gs_deff-quotation_id = ls_qh2-QuotNum.
          gs_deff-rate         = <fs_deferred>-pkond.

          gs_deff-period_type = get_domain_text(
              iv_value        =  <fs_deferred>-zpertyp ).

          gs_deff-min_amount  = <fs_deferred>-zminamt.
          gs_deff-max_amount  = <fs_deferred>-zmaxamt.
          gs_deff-flat_amount = <fs_deferred>-zflatamt.
          gs_deff-waers       = <fs_deferred>-waers.
          gs_deff-notes       = <fs_deferred>-znotes.
          APPEND gs_deff TO gs_quot_block-defe.
        ENDIF.
        UNASSIGN <fs_deferred>.

        " --- chartyp = 4 -> Discounting (gs_disc)
        CLEAR gs_disc.
        READ TABLE lt_quoti_all ASSIGNING FIELD-SYMBOL(<fs_discount>)
          WITH KEY zenqid = ls_qh2-EnqId zquotnum = ls_qh2-QuotNum zchartyp = '4'
          BINARY SEARCH.

        IF sy-subrc = 0.
          gs_disc-quotation_id = ls_qh2-QuotNum.

          gs_disc-base_rate = get_domain_text(
               iv_value        =  <fs_discount>-zbaserate ).

          gs_disc-rate = <fs_discount>-pkond.

          gs_disc-period_type = get_domain_text(
              iv_value        =  <fs_discount>-zpertyp ).

          gs_disc-waers = <fs_discount>-waers.
          gs_disc-notes = <fs_discount>-znotes.
          APPEND gs_disc TO gs_quot_block-disc.
        ENDIF.
        UNASSIGN <fs_discount>.

      ENDLOOP.

      IF lv_prev_quotnum IS NOT INITIAL AND gs_quot_block-quot IS NOT INITIAL.
        APPEND gs_quot_block TO gt_quot_block.
      ENDIF.

      " ----------------------------------------------------------------
      " Chiamata RFC Asincrona (spero sia cosi')
      " ----------------------------------------------------------------
      CALL FUNCTION 'ZFI_GENERATE_QUOTATION_PDF'
        STARTING NEW TASK 'SEND_PDF_EMAIL'
        EXPORTING
          is_head          = gs_head
          it_so            = gt_so
          it_issue         = gt_issue
          it_quot_block    = gt_quot_block
          it_recipients_to = lt_to
          it_recipients_cc = lt_cc
          iv_subject       = lv_subject
          it_body          = lt_body
          iv_enqid         = ls_header-EnqId
          iv_confbank      = ls_bank-zconfbank
          iv_event         = lv_operation+1.

    ENDLOOP.

  ENDMETHOD.

  METHOD Send_Mails_For_Enquiry.

    DATA: lt_quot_all  TYPE STANDARD TABLE OF zfirfq_quoth WITH EMPTY KEY,
          lt_quoti_all TYPE STANDARD TABLE OF zfirfq_quoti WITH EMPTY KEY,
          lt_group_key TYPE STANDARD TABLE OF zfirfq_quoth-zconfbank WITH EMPTY KEY,
          lt_quot_bank TYPE STANDARD TABLE OF zfirfq_quoth WITH EMPTY KEY.

    DATA: gs_head  TYPE zsfi_ifmlc_head,
          gt_so    TYPE zsfi_ifmlc_so_t,
          gs_so    TYPE zsfi_ifmlc_so,
          gt_issue TYPE zsfi_ifmlc_issu_t,
          gs_issue TYPE zsfi_ifmlc_issu.

    FIELD-SYMBOLS: <fs_commit> TYPE zfirfq_quoti,
                   <fs_def>    TYPE zfirfq_quoti,
                   <fs_disc>   TYPE zfirfq_quoti.

    " Lettura quotazioni per stato CHO / DEC
    SELECT * FROM zfirfq_quoth
      INTO TABLE @lt_quot_all
      WHERE zenqid = @iv_enqid
        AND zquotstatus IN ( 'CHO', 'DEC' ).

    IF lt_quot_all IS INITIAL.
      RETURN.
    ENDIF.

    " Lettura item quotation
    SELECT * FROM zfirfq_quoti
      INTO TABLE @lt_quoti_all
      FOR ALL ENTRIES IN @lt_quot_all
      WHERE zenqid  = @lt_quot_all-zenqid
        AND zquotnum = @lt_quot_all-zquotnum.

    SORT lt_quoti_all BY zenqid zquotnum zchartyp.

    " Lettura header RAP (per gs_head, gt_so, gt_issue)
    READ ENTITIES OF zi_fi_rfq_header IN LOCAL MODE
      ENTITY RfqHeader
        ALL FIELDS
        WITH VALUE #( ( %key = iv_enqid ) )
      RESULT DATA(lt_header).

    READ TABLE lt_header INDEX 1 INTO DATA(ls_header).
    CHECK sy-subrc = 0.

    " Sales Orders
    READ ENTITIES OF zi_fi_rfq_header IN LOCAL MODE
      ENTITY RfqHeader BY \_SalesOrders
        ALL FIELDS
        WITH VALUE #( ( %tky = ls_header-%tky ) )
      RESULT DATA(lt_so).

    " Issuing Banks
    READ ENTITIES OF zi_fi_rfq_header IN LOCAL MODE
      ENTITY RfqHeader BY \_IssuingBanks
        ALL FIELDS
        WITH VALUE #( ( %tky = ls_header-%tky ) )
      RESULT DATA(lt_issb).

    " Popolamento gs_head
    CLEAR gs_head.
    gs_head-inquiry_id       = ls_header-EnqId.
    gs_head-request_person   = ls_header-RequestorFullName.
    gs_head-person_charge    = ls_header-PersonInChargeFullName.

    SELECT SINGLE butxt
      FROM t001
      WHERE bukrs = @ls_header-Beneficiary
      INTO @gs_head-beneficiary.

    gs_head-customer         = ls_header-Customer && ' ' && ls_header-CustomerCountryMan.
    gs_head-tolerance_n      = ls_header-NegTolerance.
    gs_head-tolerance_p      = ls_header-PosTolerance.
    gs_head-fob_place        = ls_header-FobPlace.
    gs_head-destinations     = ls_header-DestCountryName.
    gs_head-description      = ls_header-DeliveryTerms3.
    gs_head-latest_ship_date = ls_header-DeliveryDate.
    gs_head-expiry_date      = ls_header-ExpiryDate.
    gs_head-payment_terms    = ls_header-PaymentTermsText.
    gs_head-expected_date    = ls_header-ExpIssDate.
    gs_head-amount           = ls_header-Amount.
    gs_head-currency         = ls_header-Currency.

    gs_head-confirmation_charges = get_domain_text( iv_value = ls_header-ConfChargePayer ).
    gs_head-discount_charges     = get_domain_text( iv_value = ls_header-DiscChargePayer ).
    gs_head-deferred_payer       = get_domain_text( iv_value = ls_header-DefChargePayer ).

    gs_head-prod_type        = ls_header-ProdTyp.
    gs_head-bukrs            = ls_header-Beneficiary.
    gs_head-issuing_country  = ls_header-DestCountryBankName.
    gs_head-issuing_country_code = ls_header-DestCountry.

    " Popolamento gt_so
    CLEAR gt_so.
    LOOP AT lt_so INTO DATA(ls_so).
      CLEAR gs_so.
      gs_so-so = ls_so-SalesOrder.
      APPEND gs_so TO gt_so.
    ENDLOOP.

    " Popolamento gt_issue
    CLEAR gt_issue.
    LOOP AT lt_issb INTO DATA(ls_issb).
      CLEAR gs_issue.
      gs_issue-issuing_bank_name    = ls_issb-BankName.
      gs_issue-issuing_bank_country = ls_issb-City.
      APPEND gs_issue TO gt_issue.
    ENDLOOP.

    " Elenco combinazioni uniche (zconfbank, zquotstatus)
    TYPES: BEGIN OF ty_group_key,
             zconfbank   TYPE zfirfq_quoth-zconfbank,
             zquotstatus TYPE zfirfq_quoth-zquotstatus,
           END OF ty_group_key.

    DATA: lt_unique_groups TYPE STANDARD TABLE OF ty_group_key WITH EMPTY KEY,
          ls_group_key     TYPE ty_group_key.

    LOOP AT lt_quot_all INTO DATA(ls_q).
      IF ls_q-zconfbank IS NOT INITIAL.
        ls_group_key-zconfbank   = ls_q-zconfbank.
        ls_group_key-zquotstatus = ls_q-zquotstatus.

        " Controllo manuale per evitare duplicati
        READ TABLE lt_unique_groups TRANSPORTING NO FIELDS
          WITH KEY zconfbank   = ls_group_key-zconfbank
                   zquotstatus = ls_group_key-zquotstatus.
        IF sy-subrc <> 0.
          APPEND ls_group_key TO lt_unique_groups.
        ENDIF.
      ENDIF.
    ENDLOOP.

    SORT lt_unique_groups BY zconfbank zquotstatus.

    " Ciclo su ogni coppia (banca, stato)
    LOOP AT lt_unique_groups INTO DATA(ls_key).

      DATA(lv_bank)   = ls_key-zconfbank.
      DATA(lv_status) = ls_key-zquotstatus.

      " Determino evento
      DATA(lv_event) = 0.
      CASE lv_status.
        WHEN 'CHO'.
          lv_event = 2.
        WHEN 'DEC'.
          lv_event = 3.
      ENDCASE.

      IF lv_event = 0.
        CONTINUE.
      ENDIF.

      " Seleziono solo le quotation per questa banca e stato
      CLEAR lt_quot_bank.
      LOOP AT lt_quot_all INTO DATA(ls_tmp)
        WHERE zconfbank   = lv_bank
          AND zquotstatus = lv_status.
        APPEND ls_tmp TO lt_quot_bank.
      ENDLOOP.

      IF lt_quot_bank IS INITIAL.
        CONTINUE.
      ENDIF.

      " Costruisco i blocchi per ZFI_GENERATE_QUOTATION_PDF
      DATA: gt_quot_block TYPE zsfi_ifmlc_quot_block_t,
            gs_quot_block TYPE zsfi_ifmlc_quot_block,
            gs_quot       TYPE zsfi_ifmlc_quot,
            gs_conf       TYPE zsfi_ifmlc_comm,
            gs_deff       TYPE zsfi_ifmlc_comm,
            gs_disc       TYPE zsfi_ifmlc_disc.

      CLEAR gt_quot_block.

      SORT lt_quot_bank BY zquotnum.
      DATA(lv_prev_quotnum) = ''.

      LOOP AT lt_quot_bank INTO DATA(ls_q2).

        IF lv_prev_quotnum <> ls_q2-zquotnum.
          IF lv_prev_quotnum IS NOT INITIAL AND gs_quot_block-quot IS NOT INITIAL.
            APPEND gs_quot_block TO gt_quot_block.
          ENDIF.

          CLEAR: gs_quot_block, gs_quot_block-quot, gs_quot_block-conf,
                 gs_quot_block-defe, gs_quot_block-disc.

          gs_quot_block-quotation_id = ls_q2-zquotnum.
          lv_prev_quotnum = ls_q2-zquotnum.
        ENDIF.

        " Quotation header
        CLEAR gs_quot.
        gs_quot-quotation_id = ls_q2-zquotnum.
        gs_quot-status = get_domain_text( iv_value = ls_q2-zquotstatus ).
        gs_quot-issuing_bank    = ls_q2-zissbnkname.
        gs_quot-advising_bank   = ls_q2-zadvbank.
        gs_quot-confirming_bank = ls_q2-zconfbank.
        gs_quot-currency        = ls_q2-waers.
        gs_quot-notes           = ls_q2-znotes.
        APPEND gs_quot TO gs_quot_block-quot.

        " Commitment
        CLEAR gs_conf.
        READ TABLE lt_quoti_all ASSIGNING <fs_commit>
          WITH KEY zenqid = ls_q2-zenqid zquotnum = ls_q2-zquotnum zchartyp = '2'
          BINARY SEARCH.

        IF sy-subrc = 0.
          gs_conf-quotation_id = ls_q2-zquotnum.
          gs_conf-rate         = <fs_commit>-pkond.
          gs_conf-period_type = get_domain_text( iv_value = <fs_commit>-zpertyp ).
          gs_conf-min_amount  = <fs_commit>-zminamt.
          gs_conf-max_amount  = <fs_commit>-zmaxamt.
          gs_conf-flat_amount = <fs_commit>-zflatamt.
          gs_conf-waers       = <fs_commit>-waers.
          gs_conf-notes       = <fs_commit>-znotes.
          APPEND gs_conf TO gs_quot_block-conf.
        ENDIF.

        " Deferred
        CLEAR gs_deff.
        READ TABLE lt_quoti_all ASSIGNING <fs_def>
          WITH KEY zenqid = ls_q2-zenqid zquotnum = ls_q2-zquotnum zchartyp = '3'
          BINARY SEARCH.

        IF sy-subrc = 0.
          gs_deff-quotation_id = ls_q2-zquotnum.
          gs_deff-rate         = <fs_def>-pkond.
          gs_deff-period_type  = get_domain_text( iv_value = <fs_def>-zpertyp ).
          gs_deff-min_amount   = <fs_def>-zminamt.
          gs_deff-max_amount   = <fs_def>-zmaxamt.
          gs_deff-flat_amount  = <fs_def>-zflatamt.
          gs_deff-waers        = <fs_def>-waers.
          gs_deff-notes        = <fs_def>-znotes.
          APPEND gs_deff TO gs_quot_block-defe.
        ENDIF.

        " Discount
        CLEAR gs_disc.
        READ TABLE lt_quoti_all ASSIGNING <fs_disc>
          WITH KEY zenqid = ls_q2-zenqid zquotnum = ls_q2-zquotnum zchartyp = '4'
          BINARY SEARCH.

        IF sy-subrc = 0.
          gs_disc-quotation_id = ls_q2-zquotnum.
          gs_disc-base_rate    = get_domain_text( iv_value = <fs_disc>-zbaserate ).
          gs_disc-rate         = <fs_disc>-pkond.
          gs_disc-period_type  = get_domain_text( iv_value = <fs_disc>-zpertyp ).
          gs_disc-waers        = <fs_disc>-waers.
          gs_disc-notes        = <fs_disc>-znotes.
          APPEND gs_disc TO gs_quot_block-disc.
        ENDIF.

      ENDLOOP.

      IF lv_prev_quotnum IS NOT INITIAL AND gs_quot_block-quot IS NOT INITIAL.
        APPEND gs_quot_block TO gt_quot_block.
      ENDIF.

      TRY.
          CALL FUNCTION 'ZFI_GENERATE_QUOTATION_PDF'
            STARTING NEW TASK 'SEND_PDF_EMAIL'
            EXPORTING
              is_head       = gs_head
              it_so         = gt_so
              it_issue      = gt_issue
              it_quot_block = gt_quot_block
              iv_enqid      = ls_header-EnqId
              iv_confbank   = lv_bank
              iv_event      = lv_event.
        CATCH cx_root INTO DATA(lx_error).
          " Logga eventuali errori
      ENDTRY.

    ENDLOOP.

  ENDMETHOD.

ENDCLASS.

*CLASS lsc_saver DEFINITION INHERITING FROM cl_abap_behavior_saver.
*
*  PROTECTED SECTION.
*    METHODS save_modified REDEFINITION.
*
*    METHODS cleanup_finalize REDEFINITION.
*
*
*ENDCLASS.
*
*CLASS lsc_saver IMPLEMENTATION.
*
*
*
*    METHOD save_modified.
*    BrEAK-POINT.
*    ENDMETHOD.
**
*    METHOD cleanup_finalize.
*   BrEAK-POINT.
*    ENDMETHOD.
*ENDCLASS.