class ZCL_FI_LCQUOT_USER definition
  public
  final
  create public .

public section.

  interfaces IF_RAP_QUERY_PROVIDER .
protected section.
private section.
ENDCLASS.



CLASS ZCL_FI_LCQUOT_USER IMPLEMENTATION.


  method IF_RAP_QUERY_PROVIDER~SELECT.

    DATA lt_result TYPE STANDARD TABLE OF zi_fi_lc_user_role.
    DATA ls_result LIKE LINE OF lt_result.
    DATA lt_roles  TYPE STANDARD TABLE OF agr_users.

     DATA: lv_addrnumber TYPE usr21-addrnumber,
          lv_persnumber TYPE usr21-persnumber,
          lv_email      TYPE adr6-smtp_addr.

    " OBBLIGATORIO per RAP altrimenti mi genera un errore
    DATA(lo_filter) = io_request->get_filter( ).


    DATA: ls_address TYPE bapiaddr3,
          lt_return  TYPE bapiret2_t.

    CALL FUNCTION 'BAPI_USER_GET_DETAIL'
      EXPORTING
        username = sy-uname
      IMPORTING
        address  = ls_address
      TABLES
        return   = lt_return.

    ls_result-dummy_key = '1'.
    ls_result-username  = sy-uname.
    ls_result-email = ls_address-e_mail.
    ls_result-description = ls_address-department.
    ls_result-description2 = ls_address-fullname.



    APPEND ls_result TO lt_result.

    io_response->set_total_number_of_records( 1 ).
    io_response->set_data( lt_result ).

  endmethod.
ENDCLASS.