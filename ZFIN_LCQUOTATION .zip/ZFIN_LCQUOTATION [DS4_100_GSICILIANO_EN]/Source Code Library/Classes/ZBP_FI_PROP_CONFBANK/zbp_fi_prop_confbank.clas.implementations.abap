CLASS lhc_confbankfee DEFINITION INHERITING FROM cl_abap_behavior_handler.

  PRIVATE SECTION.

    METHODS:

      " ── Determinations ────────────────────────────────────────────────────
      set_admin_fields FOR DETERMINE ON MODIFY
        IMPORTING keys FOR ConfBankFee~set_admin_fields,

      " ── Validations ───────────────────────────────────────────────────────
*      validate_valid_from FOR VALIDATE ON SAVE
*        IMPORTING keys FOR ConfBankFee~validate_valid_from,

      validate_rate FOR VALIDATE ON SAVE
        IMPORTING keys FOR ConfBankFee~validate_rate,

      validate_bukrs FOR VALIDATE ON SAVE
        IMPORTING keys FOR ConfBankFee~validate_bukrs,

      get_instance_authorizations FOR INSTANCE AUTHORIZATION
        IMPORTING keys REQUEST requested_authorizations FOR ConfBankFee RESULT result,

      authority_check_bukrs
        IMPORTING iv_bukrs             TYPE bukrs
                  iv_actvt             TYPE activ_auth
        RETURNING VALUE(rv_authorized) TYPE abap_bool,

      CancelBankFee FOR MODIFY
        IMPORTING keys FOR ACTION ConfBankFee~CancelBankFee RESULT result,

      CheckDuplicate FOR MODIFY
        IMPORTING keys FOR ACTION ConfBankFee~CheckDuplicate RESULT result.


ENDCLASS.

CLASS lhc_confbankfee IMPLEMENTATION.

  " ── set_admin_fields ──────────────────────────────────────────────────────
  " Sets CreatedBy/CreatedAt on create, ChangedBy/ChangedAt on every modify.
  METHOD set_admin_fields.

    READ ENTITIES OF zi_fi_prop_confbank IN LOCAL MODE
      ENTITY ConfBankFee
        FIELDS ( CreatedBy CreatedAt )
        WITH CORRESPONDING #( keys )
      RESULT DATA(lt_fees).

    DATA lt_update TYPE TABLE FOR UPDATE zi_fi_prop_confbank\\ConfBankFee.

    DATA(lv_today) = cl_abap_context_info=>get_system_date( ).
    DATA(lv_user)  = cl_abap_context_info=>get_user_alias( ).

    " Declare ls_update explicitly instead of relying on VALUE #( ) inference
    DATA ls_update LIKE LINE OF lt_update.

    LOOP AT lt_fees INTO DATA(ls_fee).

      CLEAR ls_update.

      ls_update-%tky      = ls_fee-%tky.
      ls_update-ChangedBy = lv_user.
      ls_update-ChangedAt = lv_today.
      ls_update-%control-ChangedBy = if_abap_behv=>mk-on.
      ls_update-%control-ChangedAt = if_abap_behv=>mk-on.

      " Set CreatedBy/CreatedAt only on first creation (when still initial)
      IF ls_fee-CreatedBy IS INITIAL.
        ls_update-CreatedBy          = lv_user.
        ls_update-CreatedAt          = lv_today.
        ls_update-%control-CreatedBy = if_abap_behv=>mk-on.
        ls_update-%control-CreatedAt = if_abap_behv=>mk-on.
      ENDIF.

      APPEND ls_update TO lt_update.
    ENDLOOP.

    MODIFY ENTITIES OF zi_fi_prop_confbank IN LOCAL MODE
      ENTITY ConfBankFee UPDATE FIELDS ( CreatedBy CreatedAt ChangedBy ChangedAt )
        WITH lt_update
      REPORTED DATA(lt_reported).


  ENDMETHOD.

  " ── validate_valid_from ───────────────────────────────────────────────────
  " ValidFrom must not be in the past on create.
*  METHOD validate_valid_from.
*
*    READ ENTITIES OF zi_fi_prop_confbank IN LOCAL MODE
*      ENTITY ConfBankFee
*        FIELDS ( ValidFrom )
*        WITH CORRESPONDING #( keys )
*      RESULT DATA(lt_fees).
*
*    DATA(lv_today) = cl_abap_context_info=>get_system_date( ).
*
*    LOOP AT lt_fees INTO DATA(ls_fee).
*      IF ls_fee-ValidFrom < lv_today.
*        APPEND VALUE #(
*          %tky = ls_fee-%tky
*          %state_area = 'VALIDATE_VALID_FROM'
*        ) TO reported-confbankfee.
*
*        APPEND VALUE #(
*          %tky = ls_fee-%tky
*        ) TO failed-confbankfee.
*
*        APPEND VALUE #(
*          %tky        = ls_fee-%tky
*          %state_area = 'VALIDATE_VALID_FROM'
*          %msg        = new_message_with_text(
*                          severity = if_abap_behv_message=>severity-error
*                          text     = 'Valid From date cannot be in the past'
*                        )
*          %element-ValidFrom = if_abap_behv=>mk-on
*        ) TO reported-confbankfee.
*      ENDIF.
*    ENDLOOP.
*
*  ENDMETHOD.

  " ── validate_rate ─────────────────────────────────────────────────────────
  " Rate must be >= 0 when provided.
  METHOD validate_rate.

    READ ENTITIES OF zi_fi_prop_confbank IN LOCAL MODE
      ENTITY ConfBankFee
        FIELDS ( Rate )
        WITH CORRESPONDING #( keys )
      RESULT DATA(lt_fees).

    LOOP AT lt_fees INTO DATA(ls_fee).
      IF ls_fee-Rate < 0.
        APPEND VALUE #(
          %tky = ls_fee-%tky
          %state_area = 'VALIDATE_RATE'
        ) TO reported-confbankfee.

        APPEND VALUE #(
          %tky = ls_fee-%tky
        ) TO failed-confbankfee.

        APPEND VALUE #(
          %tky        = ls_fee-%tky
          %state_area = 'VALIDATE_RATE'
          %msg        = new_message_with_text(
                          severity = if_abap_behv_message=>severity-error
                          text     = 'Rate must be greater than or equal to 0'
                        )
          %element-Rate = if_abap_behv=>mk-on
        ) TO reported-confbankfee.
      ENDIF.
    ENDLOOP.

  ENDMETHOD.

*  -------------- VALIDATE E AUTH CHECK --------------------
  METHOD authority_check_bukrs.
    AUTHORITY-CHECK OBJECT 'ZBUKRS'
      ID 'BUKRS' FIELD iv_bukrs
      ID 'ACTVT' FIELD iv_actvt.
    rv_authorized = xsdbool( sy-subrc = 0 ).
  ENDMETHOD.


  METHOD validate_bukrs.
    READ ENTITIES OF zi_fi_prop_confbank IN LOCAL MODE
      ENTITY ConfBankFee
        FIELDS ( CompanyCode )
        WITH CORRESPONDING #( keys )
      RESULT DATA(lt_fees).

    LOOP AT lt_fees INTO DATA(ls_fee).
      IF authority_check_bukrs( iv_bukrs = ls_fee-CompanyCode iv_actvt = '02' ) = abap_false.
        APPEND VALUE #( %tky = ls_fee-%tky ) TO failed-ConfBankFee.
        APPEND VALUE #(
          %tky = ls_fee-%tky
          %msg = new_message_with_text(
                   severity = if_abap_behv_message=>severity-error
                   text     = |Not authorized for company { ls_fee-CompanyCode }| )
        ) TO reported-ConfBankFee.
      ENDIF.
    ENDLOOP.
  ENDMETHOD.

  METHOD get_instance_authorizations.
    READ ENTITIES OF zi_fi_prop_confbank IN LOCAL MODE
      ENTITY ConfBankFee
        FIELDS ( CompanyCode )
        WITH CORRESPONDING #( keys )
      RESULT DATA(lt_fees).

    DATA ls_result LIKE LINE OF result.

    LOOP AT lt_fees INTO DATA(ls_fee).
      CLEAR ls_result.
      ls_result-%tky = ls_fee-%tky.

      IF authority_check_bukrs( iv_bukrs = ls_fee-CompanyCode iv_actvt = '02' ) = abap_true.
        ls_result-%update               = if_abap_behv=>auth-allowed.
        ls_result-%delete               = if_abap_behv=>auth-allowed.
        ls_result-%action-CancelBankFee = if_abap_behv=>auth-allowed.
      ELSE.
        ls_result-%update               = if_abap_behv=>auth-unauthorized.
        ls_result-%delete               = if_abap_behv=>auth-unauthorized.
        ls_result-%action-CancelBankFee = if_abap_behv=>auth-unauthorized.
      ENDIF.

      APPEND ls_result TO result.
    ENDLOOP.
  ENDMETHOD.

  METHOD CancelBankFee.

    READ ENTITIES OF zi_fi_prop_confbank IN LOCAL MODE
      ENTITY ConfBankFee
        FIELDS ( BpId ProdType CharType ValidFrom  )
        WITH CORRESPONDING #( keys )
      RESULT DATA(lt_fees).

    LOOP AT lt_fees INTO DATA(ls_fees).

       IF ls_fees-Inactive = abap_true.
         APPEND VALUE #(
          %tky = ls_fees-%tky
          %msg = new_message_with_text(
                   severity = if_abap_behv_message=>severity-error
                   text     = |Fee { ls_fees-BpId } already cancelled| )
        ) TO reported-ConfBankFee.
        APPEND VALUE #( %tky = ls_fees-%tky ) TO failed-ConfBankFee.
        CONTINUE.

       ENDIF.

      MODIFY ENTITIES OF zi_fi_prop_confbank IN LOCAL MODE
          ENTITY ConfBankFee
          UPDATE FIELDS ( Inactive )
        WITH VALUE #( ( %tky = ls_fees-%tky Inactive = abap_true ) ).

    ENDLOOP.



    READ ENTITIES OF zi_fi_prop_confbank IN LOCAL MODE
      ENTITY ConfBankFee ALL FIELDS
      WITH CORRESPONDING #( keys )
      RESULT DATA(lt_result).
    result = VALUE #( FOR ls IN lt_result ( %tky = ls-%tky %param = ls ) ).
  ENDMETHOD.


METHOD CheckDuplicate.


    READ TABLE keys INDEX 1 INTO DATA(ls_key).
        DATA(ls_param) = ls_key-%param.

    SELECT SINGLE zbpid, zprodtyp, bukrs, zvalidfrom
      FROM zfirfq_bankfee
      WHERE zbpid      = @ls_param-BpId
        AND bukrs     = @ls_param-CompanyCode
        AND zprodtyp   = @ls_param-ProdType
        AND zvalidfrom = @ls_param-ValidFrom
      INTO @DATA(ls_exists).

    IF sy-subrc = 0.


      APPEND VALUE #(
        %cid        = ls_key-%cid
        %param      = VALUE #(
            IsDuplicate = 'X'
            Message = 'Already exist combination of Bank/Company/Product/Date')
      ) TO result.

    ELSE.
      " Nessun duplicato → OK
      APPEND VALUE #(
        %cid        = ls_key-%cid
        %param = VALUE #(
          IsDuplicate = ''
          Message     = ''
        )
      ) TO result.
    ENDIF.

  ENDMETHOD.

ENDCLASS.