CLASS zbp_fi_prop_confbank DEFINITION
    PUBLIC
    ABSTRACT
    FINAL
    FOR BEHAVIOR OF zi_fi_prop_confbank.
ENDCLASS.

CLASS zbp_fi_prop_confbank IMPLEMENTATION.
ENDCLASS.