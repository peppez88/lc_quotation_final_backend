CLASS zcl_fi_lc_item_virtual DEFINITION
  PUBLIC FINAL
  CREATE PUBLIC.

  PUBLIC SECTION.
    INTERFACES if_sadl_exit_calc_element_read.
ENDCLASS.

CLASS zcl_fi_lc_item_virtual IMPLEMENTATION.

  METHOD if_sadl_exit_calc_element_read~get_calculation_info.
    " Dichiara quali campi della CDS ti servono per il calcolo
    " (cuobj è necessario per chiamare la FM)
    APPEND 'MATERIALCONF' TO et_requested_orig_elements.
  ENDMETHOD.

  METHOD if_sadl_exit_calc_element_read~calculate.
    " it_original_data  = righe lette dalla CDS (con MaterialConf)
    " ct_calculated_data = tabella da arricchire con i virtual elements

    DATA lt_original TYPE STANDARD TABLE OF ZI_FI_LC_SALESORDERITEM
                     WITH DEFAULT KEY.
    DATA lt_result   TYPE STANDARD TABLE OF ZI_FI_LC_SALESORDERITEM
                     WITH DEFAULT KEY.

    " Cast delle tabelle generiche
    lt_original = CORRESPONDING #( it_original_data ).

    LOOP AT lt_original INTO DATA(ls_item).
      DATA(lv_cuobj) = ls_item-materialconf.

      IF lv_cuobj IS INITIAL OR
         lv_cuobj = '000000000000000000'.
        APPEND CORRESPONDING #( ls_item ) TO lt_result.
        CONTINUE.
      ENDIF.

      DATA lt_conf TYPE STANDARD TABLE OF conf_out.

      CALL FUNCTION 'VC_I_GET_CONFIGURATION'
        EXPORTING
          instance          = lv_cuobj
          language          = sy-langu
          iv_no_value_check = 'X'
          iv_no_description = ' '
        TABLES
          configuration     = lt_conf
        EXCEPTIONS
          OTHERS            = 4.

      DATA(ls_result) = CORRESPONDING ZI_FI_LC_SALESORDERITEM( ls_item ).

      IF sy-subrc = 0.
        READ TABLE lt_conf
          INTO DATA(ls_conf)
          WITH KEY atnam = 'Z_CATALOG_CD'.
        IF sy-subrc = 0.
          ls_result-catalogcode        = ls_conf-atwrt.
          ls_result-catalogdescription = ls_conf-atwtb.
        ENDIF.
      ENDIF.

      APPEND ls_result TO lt_result.
    ENDLOOP.

    ct_calculated_data = CORRESPONDING #( lt_result ).
  ENDMETHOD.

ENDCLASS.