class ZCL_FI_LCQUOT_NOTIFY definition
  public
  final
  create public .

public section.

  interfaces /IWNGW/IF_NOTIF_PROVIDER .

  types TY_T_RECIPIENTS type STANDARD TABLE OF UNAME WITH EMPTY KEY .

  class-data GV_TITLE type STRING .
  class-data GV_SUBTITLE type STRING .
  class-data GV_REQUESTOR_NAME type STRING .

  class-methods SEND_NOTIFICATION
    importing
      !IT_RECIPIENT type TY_T_RECIPIENTS
      !IV_TITLE type STRING
      !IV_SUBTITLE type STRING
      !IV_PRIORITY type STRING
      !IV_INQUIRY type ZZFIRFQ_ENQID .
protected section.
private section.
ENDCLASS.



CLASS ZCL_FI_LCQUOT_NOTIFY IMPLEMENTATION.


  METHOD /iwngw/if_notif_provider~get_notification_parameters.

  " Parametro TITLE - verrà sostituito a {title} nel template
  APPEND VALUE #( name         = 'title'
                  value        = gv_title
                  type         = 'Edm.String'
                  is_sensitive = abap_false ) TO et_parameter.

  " Parametro SUBTITLE - verrà sostituito a {subtitle} nel template
  APPEND VALUE #( name         = 'subtitle'
                  value        = gv_subtitle
                  type         = 'Edm.String'
                  is_sensitive = abap_false ) TO et_parameter.

  APPEND VALUE #( name         = 'requester_name'
                  value        = gv_requestor_name
                  type         = 'Edm.String'
                  is_sensitive = abap_false ) TO et_parameter.

  ENDMETHOD.


  METHOD /iwngw/if_notif_provider~get_notification_type.

 " lowest effort: return that the type exists
  es_notification_type-type_key     = 'LC_QUOTATION'.
  es_notification_type-version      = 0.
  es_notification_type-is_groupable = abap_true.


  ENDMETHOD.


  METHOD /iwngw/if_notif_provider~get_notification_type_text.

    CASE iv_type_key.
      WHEN 'LC_QUOTATION'.
        " Testo principale con placeholder dinamici
        es_type_text-template_public    = '{title} by {requester_name}'.
        es_type_text-template_grouped   = 'LC Quotation'.
*        es_type_text-template_sensitive = '{title} by {requester_name}'.
        es_type_text-description        = '{title}'.
        es_type_text-subtitle           = '{subtitle}'.
    ENDCASE.


  ENDMETHOD.


  METHOD /iwngw/if_notif_provider~handle_action.

* Gestione azioni utente sulla notifica (es. click su pulsante)


  ENDMETHOD.


  METHOD /iwngw/if_notif_provider~handle_bulk_action.

* Gestione azioni bulk (es. "dismiss all")
  ENDMETHOD.


METHOD send_notification.

  DATA: lt_notif        TYPE /iwngw/if_notif_provider=>ty_t_notification,
        ls_notif        LIKE LINE OF lt_notif,
        lt_recipient    TYPE /iwngw/if_notif_provider=>ty_t_notification_recipient,
        ls_recipient    LIKE LINE OF lt_recipient,
        lt_param_bundle TYPE /iwngw/if_notif_provider=>ty_t_notification_param_bundle,
        ls_param_bundle LIKE LINE OF lt_param_bundle,
        lt_parameter    TYPE /iwngw/if_notif_provider=>ty_t_notification_parameter,
        ls_parameter    LIKE LINE OF lt_parameter,
        lv_uuid         TYPE REF TO if_system_uuid,
        lrx_api         TYPE REF TO /iwngw/cx_notification_api.

  gv_title = iv_title.
  gv_subtitle = iv_subtitle.
*  gv_requestor_name = sy-uname.

SELECT adrp~name_first, adrp~name_last
  FROM usr21
  INNER JOIN adrp ON adrp~persnumber = usr21~persnumber
                  AND adrp~nation    = ''
  WHERE usr21~bname    = @sy-uname
    AND adrp~date_from <= @sy-datum
  ORDER BY adrp~date_from DESCENDING
  INTO TABLE @DATA(lt_fullname)
  UP TO 1 ROWS.

DATA(lv_fullname) = |{ lt_fullname[ 1 ]-name_first } { lt_fullname[ 1 ]-name_last }|.
gv_requestor_name = lv_fullname.



  " ID univoco notifica
  TRY.
      lv_uuid = cl_uuid_factory=>create_system_uuid( ).
      ls_notif-id = lv_uuid->create_uuid_x16( ).
    CATCH cx_uuid_error.
      CONCATENATE sy-uname sy-datum sy-uzeit INTO ls_notif-id.
  ENDTRY.

  " Tipo e priorità
  ls_notif-type_key     = 'LC_QUOTATION'.
  ls_notif-type_version = '1'.
  CASE iv_priority.
    WHEN 'HIGH'.
      ls_notif-priority     = /iwngw/if_notif_provider=>gcs_priorities-high.
    WHEN 'MEDIUM'.
      ls_notif-priority     = /iwngw/if_notif_provider=>gcs_priorities-medium.
    WHEN 'LOW'.
      ls_notif-priority     = /iwngw/if_notif_provider=>gcs_priorities-low.
    WHEN OTHERS.
      ls_notif-priority     = /iwngw/if_notif_provider=>gcs_priorities-neutral.
  ENDCASE.

  " Mittente - necessario per tab By Date
  ls_notif-actor_id           = sy-uname.
  ls_notif-actor_type         = ''.
  ls_notif-actor_display_text = sy-uname.

  " Destinatari - un recipient per ogni bname passato
  LOOP AT it_recipient INTO DATA(lv_recipient).
    CLEAR ls_recipient.
    ls_recipient-id = lv_recipient.
    APPEND ls_recipient TO lt_recipient.
  ENDLOOP.

  ls_notif-recipients = lt_recipient.

  " Parametri testo dinamici
  ls_parameter-name         = 'title'.
  ls_parameter-value        = iv_title.
  ls_parameter-type         = /iwngw/if_notif_provider=>gcs_parameter_types-type_string.
  ls_parameter-is_sensitive = abap_false.
  APPEND ls_parameter TO lt_parameter.

  ls_parameter-name         = 'requester_name'.
*  ls_parameter-value        = sy-uname.
  ls_parameter-value        = gv_requestor_name.
  ls_parameter-type         = /iwngw/if_notif_provider=>gcs_parameter_types-type_string.
  ls_parameter-is_sensitive = abap_false.
  APPEND ls_parameter TO lt_parameter.

  ls_parameter-name         = 'subtitle'.
  ls_parameter-value        = iv_subtitle.
  ls_parameter-type         = /iwngw/if_notif_provider=>gcs_parameter_types-type_string.
  ls_parameter-is_sensitive = abap_false.
  APPEND ls_parameter TO lt_parameter.

  ls_param_bundle-language   = sy-langu.
  ls_param_bundle-parameters = lt_parameter.
  APPEND ls_param_bundle TO lt_param_bundle.

  ls_notif-parameters = lt_param_bundle.

  " Link navigazione
  DATA: lt_nav_params TYPE TABLE OF /iwngw/if_notif_provider=>ty_s_navigation_parameter,
        ls_nav_param  TYPE /iwngw/if_notif_provider=>ty_s_navigation_parameter.

  ls_nav_param-name  = 'enqId'.
  ls_nav_param-value = iv_inquiry.
  APPEND ls_nav_param TO lt_nav_params.

  ls_nav_param-name  = 'mode'.
  ls_nav_param-value = 'display'.
  APPEND ls_nav_param TO lt_nav_params.

  ls_notif-navigation_target_object = 'zficreateinquiry'.
  ls_notif-navigation_target_action = 'create'.
  ls_notif-navigation_parameters = lt_nav_params.

  APPEND ls_notif TO lt_notif.

  " Pubblicazione
  TRY.
      /iwngw/cl_notification_api=>create_notifications(
        EXPORTING
          iv_provider_id  = 'ZFI_LCQUOTATION_NOTIFY'
          it_notification = lt_notif
      ).
    CATCH /iwngw/cx_notification_api INTO lrx_api.
  ENDTRY.


ENDMETHOD.
ENDCLASS.