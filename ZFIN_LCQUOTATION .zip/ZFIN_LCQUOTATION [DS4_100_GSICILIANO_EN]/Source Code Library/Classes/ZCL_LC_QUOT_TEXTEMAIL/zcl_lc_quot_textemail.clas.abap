*CLASS zcl_lc_quot_textemail DEFINITION
*  PUBLIC
*  FINAL
*  CREATE PUBLIC .
*
*  PUBLIC SECTION.
*  PROTECTED SECTION.
*  PRIVATE SECTION.
*ENDCLASS.
*
*
*
*CLASS zcl_lc_quot_textemail IMPLEMENTATION.
*ENDCLASS.
CLASS zcl_lc_quot_textemail DEFINITION
  PUBLIC FINAL
  CREATE PUBLIC.

  PUBLIC SECTION.
    INTERFACES if_rap_query_provider.

  PRIVATE SECTION.
    METHODS get_text_coordinates
      IMPORTING iv_prod_type    TYPE numc1
                iv_company_code TYPE bukrs
                iv_text_type    TYPE numc1
      EXPORTING ev_object       TYPE tdobject
                ev_id           TYPE tdid
                ev_name         TYPE tdobname
                ev_spras        TYPE spras
                ev_rc           TYPE numc2
                ev_msg          TYPE char100.

ENDCLASS.

CLASS zcl_lc_quot_textemail IMPLEMENTATION.

  METHOD if_rap_query_provider~select.

    DATA: lv_text_type    TYPE numc1,
          lv_company_code TYPE bukrs,
          lv_prod_type    TYPE zzfirfq_prodtyp.

    DATA(lt_filter_cond) = io_request->get_filter( )->get_as_ranges( ).

    DATA(lo_paging) = io_request->get_paging( ).
    DATA(lv_top)    = lo_paging->get_page_size( ).  " -1 = nessun limite
    DATA(lv_skip)   = lo_paging->get_offset( ).

    LOOP AT lt_filter_cond INTO DATA(ls_fc).
      CASE ls_fc-name.
        WHEN 'TEXTTYPE'.
          lv_text_type = ls_fc-range[ 1 ]-low.
        WHEN 'COMPANYCODE'.
          lv_company_code = ls_fc-range[ 1 ]-low.
        WHEN 'PRODUCTTYPE'.
          lv_prod_type = ls_fc-range[ 1 ]-low.
      ENDCASE.
    ENDLOOP.

    TYPES: BEGIN OF ty_result,
             id          TYPE char100,
             texttype    TYPE numc1,
             companycode TYPE bukrs,
             producttype TYPE zzfirfq_prodtyp,
             linenum     TYPE i,
             tdline      TYPE tdline,
             tdformat    TYPE tdformat,
             returncode  TYPE numc2,
             returnmsg   TYPE char100,
           END OF ty_result.

    DATA lt_result TYPE STANDARD TABLE OF ty_result.
    DATA ls_result TYPE ty_result.

    IF lv_text_type IS INITIAL.
      ls_result-id         = '0000'.
      ls_result-returncode = '02'.
      ls_result-returnmsg  = 'ProdType mancante'.
      APPEND ls_result TO lt_result.
      io_response->set_total_number_of_records( 1 ).
      io_response->set_data( lt_result ).
      RETURN.
    ENDIF.

    DATA lv_object TYPE tdobject.
    DATA lv_id     TYPE tdid.
    DATA lv_name   TYPE tdobname.
    DATA lv_spras  TYPE spras.
    DATA lv_rc     TYPE numc2.
    DATA lv_msg    TYPE char100.


    me->get_text_coordinates(
      EXPORTING iv_prod_type = lv_prod_type
                iv_company_code = lv_company_code
                iv_text_type = lv_text_type

      IMPORTING ev_object    = lv_object
                ev_id        = lv_id
                ev_name      = lv_name
                ev_spras     = lv_spras
                ev_rc        = lv_rc
                ev_msg       = lv_msg ).

    IF lv_rc <> '00'.
      ls_result-id         = |{ lv_text_type }-0000|.
      ls_result-texttype   = lv_text_type.
      ls_result-returncode = lv_rc.
      ls_result-returnmsg  = lv_msg.
      APPEND ls_result TO lt_result.
      io_response->set_total_number_of_records( 1 ).
      io_response->set_data( lt_result ).
      RETURN.
    ENDIF.

    DATA lt_lines TYPE TABLE OF tline.

    CALL FUNCTION 'READ_TEXT'
      EXPORTING
        id                      = lv_id
        language                = lv_spras
        name                    = lv_name
        object                  = lv_object
      TABLES
        lines                   = lt_lines
      EXCEPTIONS
        id                      = 1
        language                = 2
        name                    = 3
        not_found               = 4
        object                  = 5
        reference_check         = 6
        wrong_access_to_archive = 7
        OTHERS                  = 8.

    IF sy-subrc <> 0.
      ls_result-id         = |{ lv_text_type }-0000|.
      ls_result-texttype   = lv_text_type.
      ls_result-returncode = '01'.
      ls_result-returnmsg  = 'Testo non trovato'.
      APPEND ls_result TO lt_result.
    ELSE.

      DATA lv_linenum TYPE i.

*      LOOP AT lt_lines INTO DATA(ls_line).
*        CLEAR ls_result.
*        ls_result-id         = |{ lv_object }-{ lv_id }-{ lv_name }-{ lv_spras }-{ sy-tabix WIDTH = 4 PAD = '0' ALIGN = RIGHT }|.
*        ls_result-texttype   = lv_text_type.
*        ls_result-linenum    = sy-tabix.
*        ls_result-tdline     = ls_line-tdline.
*        ls_result-tdformat   = ls_line-tdformat.
*        ls_result-returncode = '00'.
*        ls_result-returnmsg  = 'OK'.
*        APPEND ls_result TO lt_result.
*      ENDLOOP.
    LOOP AT lt_lines INTO DATA(ls_line).
        CLEAR ls_result.
        lv_linenum            = sy-tabix.
        ls_result-id          = |{ lv_object }-{ lv_id }-{ lv_name }-{ lv_spras }-{ sy-tabix WIDTH = 4 PAD = '0' ALIGN = RIGHT }|.
        ls_result-texttype    = lv_text_type.
        ls_result-linenum     = lv_linenum.
        ls_result-tdline      = ls_line-tdline.
        ls_result-tdformat    = ls_line-tdformat.
        ls_result-returncode  = '00'.
        ls_result-returnmsg   = 'OK'.
        APPEND ls_result TO lt_result.
      ENDLOOP.

*****FIRMA***********
    DATA: ls_address TYPE bapiaddr3,
            lt_return  TYPE bapiret2_t.

      CALL FUNCTION 'BAPI_USER_GET_DETAIL'
        EXPORTING
          username = sy-uname
        IMPORTING
          address  = ls_address
        TABLES
          return   = lt_return.

       SELECT SINGLE *
        FROM t001
        WHERE bukrs = @lv_company_code
          AND spras = @sy-langu
        INTO @DATA(ls_t001).

       DATA: ls_adrc   TYPE adrc,
            lv_landx  TYPE landx50.

      IF ls_t001-adrnr IS NOT INITIAL.
        SELECT SINGLE *
          FROM adrc
          WHERE addrnumber = @ls_t001-adrnr
          INTO @ls_adrc.

      SELECT SINGLE landx50
          FROM t005t
          WHERE spras = @sy-langu
            AND land1 = @ls_t001-land1
          INTO @lv_landx.
      ENDIF.


      DATA lt_firma TYPE STANDARD TABLE OF char255.
      DATA lv_firma  TYPE char255.

*      CLEAR lv_firma. APPEND lv_firma TO lt_firma.
*      CLEAR lv_firma. APPEND lv_firma TO lt_firma.
*
*      lv_firma = |Thank you very much and best regards,|.
*      APPEND lv_firma TO lt_firma.

      lv_firma = |{ ls_address-firstname }|.
      APPEND lv_firma TO lt_firma.

      lv_firma = |--------------------------------------------------|.
      APPEND lv_firma TO lt_firma.

      lv_firma = |{ ls_address-fullname }|.
      APPEND lv_firma TO lt_firma.

      lv_firma = |{ ls_address-department }|.
      APPEND lv_firma TO lt_firma.

      lv_firma = |{ ls_t001-butxt }|.
      APPEND lv_firma TO lt_firma.

      lv_firma = |{ ls_adrc-street }|.
      APPEND lv_firma TO lt_firma.

      lv_firma = |{ ls_adrc-post_code1 } { ls_t001-ort01 } - { lv_landx }|.
      APPEND lv_firma TO lt_firma.

      lv_firma = |Tel: { ls_address-tel1_numbr }|.
      APPEND lv_firma TO lt_firma.

      lv_firma = |E-mail: { ls_address-e_mail }|.
      APPEND lv_firma TO lt_firma.

      LOOP AT lt_firma INTO lv_firma.
        lv_linenum = lv_linenum + 1.
        CLEAR ls_result.
        ls_result-id          = |{ lv_object }-{ lv_id }-{ lv_name }-{ lv_spras }-{ lv_linenum WIDTH = 4 PAD = '0' ALIGN = RIGHT }|.
        ls_result-texttype    = lv_text_type.
        ls_result-linenum     = lv_linenum.
        ls_result-tdline      = lv_firma.
        ls_result-tdformat    = '*'.
        ls_result-returncode  = '00'.
        ls_result-returnmsg   = 'OK'.
        APPEND ls_result TO lt_result.
      ENDLOOP.


*****FIRMA***********
    ENDIF.



    io_response->set_total_number_of_records( lines( lt_result ) ).
    io_response->set_data( lt_result ).

  ENDMETHOD.


  METHOD get_text_coordinates.

    ev_rc  = '00'.
    ev_msg = 'OK'.

    DATA lv_ztext TYPE zzfirfq_bodymail.

*    Estrazione text da tabella per nome SO10

    SELECT SINGLE ztext

      FROM zfirfq_sendmail
      INTO lv_ztext
      WHERE bukrs    = iv_company_code
        AND zprodtyp = iv_prod_type
        AND zevent   = iv_text_type
        AND zobject  = '1'.

    IF sy-subrc = 0.

      ev_object = 'TEXT'.
      ev_id     = 'ST'.
      ev_name   = lv_ztext.
      ev_spras  = sy-langu.
    ELSE.
      ev_rc  = '02'.
      ev_msg = 'ProdType sconosciuto'.
    ENDIF.


*    CASE iv_prod_type.
*      WHEN '1'.
*        ev_object = 'TEXT'.
*        ev_id     = 'ST'.
*        ev_name   = lv_ztext.
*        ev_spras  = sy-langu.
*      WHEN '2'.
*        ev_object = 'TEXT'.
*        ev_id     = 'ST'.
*        ev_name   = 'ZFIN_LC_QUOT_BODY2'.
*        ev_spras  = sy-langu.
*      WHEN '3'.
*        ev_object = 'TEXT'.
*        ev_id     = 'ST'.
*        ev_name   = 'ZFIN_LC_QUOT_BODY3'.
*        ev_spras  = sy-langu.
*      WHEN '4'.
*        ev_object = 'TEXT'.
*        ev_id     = 'ST'.
*        ev_name   = 'ZFIN_LC_QUOT_BODY4'.
*        ev_spras  = sy-langu.
*      WHEN OTHERS.
*        ev_rc  = '02'.
*        ev_msg = 'ProdType sconosciuto'.
*    ENDCASE.

  ENDMETHOD.

ENDCLASS.