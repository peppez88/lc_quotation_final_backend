CLASS zcl_fi_lc_rfq_userauth DEFINITION
  PUBLIC FINAL
  CREATE PUBLIC.

  PUBLIC SECTION.
    INTERFACES if_rap_query_provider.

  PRIVATE SECTION.
    TYPES: BEGIN OF ty_auth,
             objtype TYPE char10,
             value1  TYPE char10,
             actvt   TYPE char2,
           END OF ty_auth.
    TYPES ty_auth_t TYPE STANDARD TABLE OF ty_auth WITH EMPTY KEY.

    METHODS get_zstatus_auth
      CHANGING ct_result TYPE ty_auth_t.

    METHODS get_ztab_auth
      CHANGING ct_result TYPE ty_auth_t.

ENDCLASS.

CLASS zcl_fi_lc_rfq_userauth IMPLEMENTATION.

  METHOD if_rap_query_provider~select.

    DATA lv_objtype_filter TYPE char10.

    DATA(lt_filter_cond) = io_request->get_filter( )->get_as_ranges( ).

    DATA(lo_paging) = io_request->get_paging( ).
    DATA(lv_top)    = lo_paging->get_page_size( ).
    DATA(lv_skip)   = lo_paging->get_offset( ).

    LOOP AT lt_filter_cond INTO DATA(ls_fc).
      CASE ls_fc-name.
        WHEN 'OBJTYPE'.
          lv_objtype_filter = ls_fc-range[ 1 ]-low.
      ENDCASE.
    ENDLOOP.

    TYPES: BEGIN OF ty_result,
             requestid TYPE numc4,
             objtype   TYPE char10,
             value1    TYPE char10,
             actvt     TYPE char2,
           END OF ty_result.

    DATA ls_result TYPE ty_result.
    DATA lt_result TYPE STANDARD TABLE OF ty_result.
    DATA lt_auth    TYPE ty_auth_t.

    IF lv_objtype_filter IS INITIAL.
      lv_objtype_filter = 'ALL'.
    ENDIF.

    " ── Costruisco il risultato completo (ZSTATUS + ZTAB) ────────────
    IF lv_objtype_filter = 'ZSTATUS'.
      me->get_zstatus_auth( CHANGING ct_result = lt_auth ).

    elseIF lv_objtype_filter = 'ZTAB'.
      me->get_ztab_auth( CHANGING ct_result = lt_auth ).
    elseIF lv_objtype_filter = 'ALL'.
      me->get_zstatus_auth( CHANGING ct_result = lt_auth ).
      me->get_ztab_auth( CHANGING ct_result = lt_auth ).
    ENDIF.

    " ── Assegno il RequestId in modo centralizzato e univoco ──────────
    DATA lv_seq TYPE i.

    LOOP AT lt_auth INTO DATA(ls_auth).
      lv_seq = lv_seq + 1.
      CLEAR ls_result.
      ls_result-requestid = lv_seq.
      ls_result-objtype   = ls_auth-objtype.
      ls_result-value1    = ls_auth-value1.
      ls_result-actvt     = ls_auth-actvt.
      APPEND ls_result TO lt_result.
    ENDLOOP.

    io_response->set_total_number_of_records( lines( lt_result ) ).
    io_response->set_data( lt_result ).

  ENDMETHOD.


  METHOD get_zstatus_auth.

    DATA(lo_status_descr) = CAST cl_abap_elemdescr(
      cl_abap_typedescr=>describe_by_name( 'ZZFIRFQ_ENQSTATUS' ) ).
    DATA(lt_status_values) = lo_status_descr->get_ddic_fixed_values( ).


    LOOP AT lt_status_values INTO DATA(ls_status).
      AUTHORITY-CHECK OBJECT 'ZSTATUS'
        ID 'ZSTATUS' FIELD ls_status-low
        ID 'ACTVT'    FIELD '02'.
      IF sy-subrc = 0.
        APPEND VALUE #(
          objtype = 'ZSTATUS'
          value1  = ls_status-low
          actvt   = '02'
        ) TO ct_result.
      ENDIF.
    ENDLOOP.

  ENDMETHOD.


  METHOD get_ztab_auth.

    DATA lt_tab_values TYPE STANDARD TABLE OF char10.
    lt_tab_values = VALUE #( ( 'TAB1' ) ( 'TAB2' ) ( 'TAB3' ) ( 'TAB4' ) ).

    LOOP AT lt_tab_values INTO DATA(lv_tab).
      AUTHORITY-CHECK OBJECT 'ZTAB'
        ID 'ZTAB'  FIELD lv_tab
        ID 'ACTVT' FIELD '02'.
      IF sy-subrc = 0.
        APPEND VALUE #(
          objtype = 'ZTAB'
          value1  = lv_tab
          actvt   = '02'
        ) TO ct_result.
      ENDIF.
    ENDLOOP.

  ENDMETHOD.

ENDCLASS.