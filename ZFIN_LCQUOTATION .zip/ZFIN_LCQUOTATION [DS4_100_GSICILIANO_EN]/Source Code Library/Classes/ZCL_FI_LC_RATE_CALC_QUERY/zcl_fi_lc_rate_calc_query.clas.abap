CLASS zcl_fi_lc_rate_calc_query DEFINITION
  PUBLIC FINAL
  CREATE PUBLIC.

  PUBLIC SECTION.
    INTERFACES if_rap_query_provider.

  PRIVATE SECTION.
    "leggo CoF da ZFINABANKINSRATE
    METHODS get_cof_rate
      IMPORTING iv_bukrs    TYPE bukrs
                iv_date     TYPE dats
                iv_waers    TYPE waers
                iv_partner  TYPE bu_partner
      EXPORTING ev_cof_perc TYPE zbankinsrate   " era p
                ev_source   TYPE char10
                ev_hbkid    TYPE hbkid
                ev_rc       TYPE numc2
                ev_msg      TYPE char100.

    " legge da T056P
    METHODS get_t056p_rate
      IMPORTING iv_date     TYPE dats
                iv_referenz TYPE char10
      EXPORTING ev_zsoll    TYPE azinssatz " era p
                ev_rc       TYPE numc2
                ev_msg      TYPE char100.

    METHODS get_payterms_days
      IMPORTING iv_date     TYPE dats
                iv_payterms TYPE dzterm
      EXPORTING ev_zpaytermsdays  TYPE dzbd1t
                ev_rc       TYPE numc2
                ev_msg      TYPE char100.
ENDCLASS.

CLASS zcl_fi_lc_rate_calc_query IMPLEMENTATION.

  METHOD if_rap_query_provider~select.

    DATA lv_baserate TYPE numc1.
    DATA lv_refdate    TYPE dats.
    DATA lv_bukrs      TYPE bukrs.
    DATA lv_waers      TYPE waers.
    DATA lv_partner    TYPE bu_partner.
    DATA lv_referenz   TYPE char10.
    DATA lv_payterms   TYPE dzterm.

    "Estraggo i parametri dai filtri
    DATA(lt_filter_cond) = io_request->get_filter( )->get_as_ranges( ).

    DATA(lo_paging) = io_request->get_paging( ).
    DATA(lv_top)    = lo_paging->get_page_size( ).  " -1 = nessun limite
    DATA(lv_skip)   = lo_paging->get_offset( ).

    LOOP AT lt_filter_cond INTO DATA(ls_fc).
      CASE ls_fc-name.
        WHEN 'BASERATE'.
          lv_baserate = ls_fc-range[ 1 ]-low.
        WHEN 'REFDATE'.
          lv_refdate = ls_fc-range[ 1 ]-low.
        WHEN 'COMPANYCODE'.
          lv_bukrs = ls_fc-range[ 1 ]-low.
        WHEN 'CURRENCY'.
          lv_waers = ls_fc-range[ 1 ]-low.
        WHEN 'PARTNER'.
          lv_partner = ls_fc-range[ 1 ]-low.
        WHEN 'REFERENZKEY'.
          lv_referenz = ls_fc-range[ 1 ]-low.
        WHEN 'PAYTERMS'.
          lv_payterms = ls_fc-range[ 1 ]-low.
      ENDCASE.
    ENDLOOP.

    "Risultato da restituire

    TYPES: BEGIN OF ty_rate_result,
             requestid     TYPE numc1,
             baserate      TYPE zzfirfq_baserate,
             refdate       TYPE dats,
             companycode   TYPE bukrs,
             currency      TYPE waers,
             partner       TYPE bu_partner,
             referenzkey   TYPE char10,
             payterms      TYPE dzterm,
             cofperc       TYPE zbankinsrate,
             cofsource     TYPE char10,
             hbkid         TYPE hktid,
             zsoll         TYPE azinssatz,
             rate4         TYPE azinssatz,
             zpaytermsdays TYPE dzbd1t,
             returncode    TYPE numc2,
             returnmsg     TYPE char100,
           END OF ty_rate_result.

    DATA ls_result TYPE ty_rate_result.
    DATA lt_result TYPE STANDARD TABLE OF ty_rate_result.

    ls_result-baserate  = lv_baserate.
    ls_result-refdate     = lv_refdate.
    ls_result-companycode = lv_bukrs.
    ls_result-currency    = lv_waers.
    ls_result-partner     = lv_partner.
*    ls_result-referenzkey = lv_referenz.
    ls_result-payterms    = lv_payterms.



    DATA lv_tvarv_name type tvarvc-name.
    DATA lv_referenz_tvarv type T056P-referenz.

    IF lv_referenz = 'EURIBOR1M'.
        lv_tvarv_name = 'ZFI_LC_BASERATE_EURIBOR1M'.
    ELSEIF lv_referenz = 'TERMSOFR'.
        lv_tvarv_name = 'ZFI_LC_BASERATE_TERM_SOFR'.
    ENDIF.

    SELECT SINGLE low
      INTO @DATA(lv_value)
      FROM tvarvc
      WHERE name = @lv_tvarv_name.

    IF sy-subrc = 0.
       ls_result-referenzkey = lv_value.
       lv_referenz_tvarv = lv_value.
    ENDIF.

    IF lv_baserate IS NOT INITIAL.
      "Dispatch per tipo
      CASE lv_baserate.
        WHEN '2'.
          me->get_cof_rate(
            EXPORTING
              iv_bukrs    = lv_bukrs
              iv_date     = lv_refdate
              iv_waers    = lv_waers
              iv_partner  = lv_partner
            IMPORTING
              ev_cof_perc = ls_result-cofperc
              ev_source   = ls_result-cofsource
              ev_hbkid    = ls_result-hbkid
              ev_rc       = ls_result-returncode
              ev_msg      = ls_result-returnmsg
          ).

        WHEN '3' OR '4'.
          me->get_t056p_rate(
            EXPORTING
              iv_date     = lv_refdate
              iv_referenz = lv_referenz_tvarv
            IMPORTING
              ev_zsoll    = ls_result-zsoll
              ev_rc       = ls_result-returncode
              ev_msg      = ls_result-returnmsg
          ).

        WHEN OTHERS.
          ls_result-returncode = '02'.
          ls_result-returnmsg  = 'Unknown BaseRate type'.
      ENDCASE.
    ENDIF.

    IF lv_payterms IS NOT INITIAL.
        me->get_payterms_days(
          EXPORTING
            iv_date          = lv_refdate
            iv_payterms      = lv_payterms
          IMPORTING
            ev_zpaytermsdays = ls_result-zpaytermsdays
            ev_rc            = ls_result-returncode
            ev_msg           = ls_result-returnmsg
        ).

    ENDIF.

    ls_result-requestid = '1'.
    APPEND ls_result TO lt_result.
    io_response->set_total_number_of_records( 1 ).
    io_response->set_data( lt_result ).

  ENDMETHOD.


  METHOD get_cof_rate.

    ev_rc  = '01'.
    ev_msg = 'CoF not found'.

    DATA lv_hbkid TYPE hbkid.

    " Leggo i dati bancari dal Business Partner
*    SELECT SINGLE bankl, banks
*      FROM but0bk
*      WHERE partner = @iv_partner
*      INTO @DATA(ls_bp_bank).
*
*    IF sy-subrc <> 0 OR ls_bp_bank-bankl IS INITIAL.
*      " Esco poichè mancanza di dati
*      RETURN.
*    ENDIF.

    " Trovo la house bank corrispondente in T012
*    SELECT SINGLE hbkid
*      FROM t012
*      WHERE bukrs = @iv_bukrs
*        AND bankl = @ls_bp_bank-bankl
*        AND banks = @ls_bp_bank-banks
*      INTO @lv_hbkid.

    SELECT SINGLE hbkid
        FROM vtbstc1
        WHERE bukrs = @iv_bukrs
            AND partnr = @iv_partner
            AND waers = @iv_waers
        INTO @lv_hbkid.

    IF sy-subrc = 0 AND lv_hbkid IS NOT INITIAL.
      "Lettura DIRETTA con HbkId
      SELECT SINGLE cof_perc
        FROM zfinabankinsrate
        WHERE bukrs         = @iv_bukrs
          AND interest_type = 'CF'
          AND waers         = @iv_waers
          AND hbkid         = @lv_hbkid
          AND validfrom    <= @iv_date
          AND validto      >= @iv_date
        INTO @ev_cof_perc.

      IF sy-subrc = 0.
        ev_source = 'DIRECT'.
        ev_hbkid  = lv_hbkid.
        ev_rc     = '00'.
        ev_msg    = 'CoF found (direct - bank specific)'.
        RETURN.
      ENDIF.
    ENDIF.

    "lettura INDIRETTA
    SELECT SINGLE cof_perc
      FROM zfinabankinsrate
      WHERE bukrs         = @iv_bukrs
        AND interest_type = 'TH'
        AND waers         = @iv_waers
        AND validfrom    <= @iv_date
        AND validto      >= @iv_date
      INTO @ev_cof_perc.

    IF sy-subrc = 0.
      ev_source = 'INDIRECT'.
      ev_hbkid  = space.
      ev_rc     = '00'.
      ev_msg    = 'CoF found (indirect - generic rate)'.
    ELSE.
      ev_rc  = '01'.
      ev_msg = 'CoF not found neither direct nor indirect'.
    ENDIF.

  ENDMETHOD.


  METHOD get_t056p_rate.

    ev_rc  = '01'.
    ev_msg = 'T056P rate not found'.

    " estraggo da T056P
    DATA lv_converted TYPE char8.
    DATA lv_date_inv TYPE char8.

    CONCATENATE iv_date+6(2) iv_date+4(2) iv_date+0(4) INTO lv_date_inv.

    CALL FUNCTION 'CONVERSION_EXIT_INVDT_INPUT'
      EXPORTING
        input  = lv_date_inv
      IMPORTING
        output = lv_converted.

    SELECT zsoll
    FROM t056p
    WHERE referenz = @iv_referenz
      AND datab   >= @lv_converted
    ORDER BY datab DESCENDING
    INTO @ev_zsoll
    UP TO 1 ROWS.
    ENDSELECT.

    IF sy-subrc = 0.
      ev_rc  = '00'.
      ev_msg = 'T056P rate found'.
    ENDIF.

  ENDMETHOD.

  METHOD get_payterms_days.

    ev_rc  = '01'.
    ev_msg = 'PayTermsDays not found'.

    CALL FUNCTION 'FI_TERMS_OF_PAYMENT_PROPOSE'
        EXPORTING
          i_bldat         = '00000000'
          i_budat         = '00000000'
          I_ZFBDT         = iv_date
          i_zterm         = iv_payterms

        IMPORTING
          e_zbd1t         = ev_zpaytermsdays
        EXCEPTIONS
          terms_not_found = 1
          OTHERS          = 2.
      IF sy-subrc <> 0.
         ev_rc  = '01'.
           ev_msg = 'PayTermsDays not found for ' && iv_payterms.
      ELSE.
        ev_rc  = '00'.
        ev_msg = 'PayTermsDays found'.
      ENDIF.

  ENDMETHOD.

ENDCLASS.
