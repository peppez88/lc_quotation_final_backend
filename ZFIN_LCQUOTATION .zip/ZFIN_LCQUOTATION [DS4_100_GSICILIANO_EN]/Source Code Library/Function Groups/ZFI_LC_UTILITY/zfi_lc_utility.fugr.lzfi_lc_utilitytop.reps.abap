FUNCTION-POOL ZFI_LC_UTILITY.               "MESSAGE-ID ..

* INCLUDE LZFI_LC_UTILITYD...                " Local class definition