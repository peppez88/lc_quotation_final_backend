*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFI_LC_UTILITYTOP.                " Global Declarations
  INCLUDE LZFI_LC_UTILITYUXX.                " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFI_LC_UTILITYF...                " Subroutines
* INCLUDE LZFI_LC_UTILITYO...                " PBO-Modules
* INCLUDE LZFI_LC_UTILITYI...                " PAI-Modules
* INCLUDE LZFI_LC_UTILITYE...                " Events
* INCLUDE LZFI_LC_UTILITYP...                " Local class implement.
* INCLUDE LZFI_LC_UTILITYT99.                " ABAP Unit tests