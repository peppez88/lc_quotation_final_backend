FUNCTION zfi_generate_quotation_pdf
  IMPORTING
    VALUE(is_head) TYPE zsfi_ifmlc_head OPTIONAL
    VALUE(it_issue) TYPE zsfi_ifmlc_issu_t OPTIONAL
    VALUE(it_so) TYPE zsfi_ifmlc_so_t OPTIONAL
    VALUE(it_quot_block) TYPE zsfi_ifmlc_quot_block_t OPTIONAL
    VALUE(it_recipients_to) TYPE string_table OPTIONAL
    VALUE(it_recipients_cc) TYPE string_table OPTIONAL
    VALUE(iv_subject) TYPE string OPTIONAL
    VALUE(it_body) TYPE soli_tab OPTIONAL
    VALUE(iv_enqid) TYPE zzfirfq_enqid OPTIONAL
    VALUE(iv_confbank) TYPE zzfirfq_confbank OPTIONAL
    VALUE(iv_event) TYPE zzfirfq_event OPTIONAL
  EXPORTING
    VALUE(ev_pdf_xstring) TYPE fpcontent
    VALUE(ev_size) TYPE string.




  CONSTANTS: lc_adobeform TYPE fpname VALUE 'ZFI_FRMLC_QUOTATION'.

  DATA: lv_fm_name      TYPE funcname,
        ls_outputparams TYPE sfpoutputparams,
        ls_docparams    TYPE sfpdocparams,
        ls_formoutput   TYPE fpformoutput,
        lt_pdf          TYPE solix_tab,
        lv_size         TYPE so_obj_len,
        lt_body         TYPE soli_tab,
        lt_cc           TYPE string_table,
        lv_long_subject TYPE string.

  lt_body = it_body.

  " Inizializzo il subject
  lv_long_subject = iv_subject.

  "Concatenazioni per Adobeform
  CONCATENATE '+' is_head-tolerance_p+2(2)  '%'  ' / ' '-' is_head-tolerance_n+2(2) '%' INTO is_head-tolerance SEPARATED BY space.

  "gestione migliaia e decimali
  DATA: lv_amount_formatted TYPE string.

  lv_amount_formatted = |{ is_head-amount CURRENCY = is_head-currency NUMBER = USER }|.

  CONCATENATE lv_amount_formatted is_head-currency INTO is_head-amount_currency SEPARATED BY space.
  CONDENSE is_head-amount_currency.

  " Recupero email dal Person in Charge
  IF is_head-person_charge IS NOT INITIAL.

    DATA: lv_email_sender TYPE ad_smtpadr.

    SELECT SINGLE a~smtp_addr
    FROM adr6 AS a
    INNER JOIN adrp AS p ON p~persnumber = a~persnumber
    WHERE p~name_text = @is_head-person_charge
    INTO @lv_email_sender.

  ENDIF.

  " Recupero Dati Utente
  IF iv_event <> '1'.

    CLEAR lv_long_subject.

    CASE is_head-prod_type.
      WHEN '1'.
        lv_long_subject = |Final Inq. - STANDARD LC - { is_head-issuing_country_code } - Inq. { is_head-inquiry_id }|.
      WHEN '2'.
        lv_long_subject = |Final Inq. - Bank Guarantee - { is_head-issuing_country_code } - Inq. { is_head-inquiry_id }|.
      WHEN '3'.
        lv_long_subject = |Final Inq. - Avalized Draft - { is_head-issuing_country_code } - Inq. { is_head-inquiry_id }|.
      WHEN '4'.
        lv_long_subject = |Final Inq. - Standby LC - { is_head-issuing_country_code } - Inq. { is_head-inquiry_id }|.
    ENDCASE.

    DATA: ls_address TYPE bapiaddr3,
          lt_return  TYPE bapiret2_t.

    CLEAR lt_body.

    SELECT SINGLE ztext
    FROM zfirfq_sendmail
    WHERE bukrs = @is_head-bukrs
    AND zprodtyp = @is_head-prod_type
    AND zevent = @iv_event
    INTO @DATA(lv_text).

    IF sy-subrc IS INITIAL.

      DATA lv_object TYPE tdobject.
      DATA lv_id     TYPE tdid.
      DATA lv_name   TYPE tdobname.
      DATA lv_spras  TYPE spras.

      lv_object = 'TEXT'.
      lv_id    = 'ST'.
      lv_name  = lv_text.
      lv_spras = sy-langu.

      DATA lt_lines TYPE TABLE OF tline.

      CALL FUNCTION 'READ_TEXT'
        EXPORTING
          id                      = lv_id
          language                = lv_spras
          name                    = lv_name
          object                  = lv_object
        TABLES
          lines                   = lt_lines
        EXCEPTIONS
          id                      = 1
          language                = 2
          name                    = 3
          not_found               = 4
          object                  = 5
          reference_check         = 6
          wrong_access_to_archive = 7
          OTHERS                  = 8.
      IF sy-subrc <> 0.

        MESSAGE ID sy-msgid TYPE sy-msgty NUMBER sy-msgno
        WITH sy-msgv1 sy-msgv2 sy-msgv3 sy-msgv4.

      ELSE.

        DATA: lv_line_body LIKE LINE OF lt_body.
        CLEAR lt_body.

        LOOP AT lt_lines INTO DATA(ls_line).
          lv_line_body-line = ls_line-tdline.
          APPEND lv_line_body TO lt_body.
        ENDLOOP.

      ENDIF.

    ENDIF.

    DATA: lt_idd07v TYPE TABLE OF dd07v WITH HEADER LINE.

    CALL FUNCTION 'DD_DOMVALUES_GET'
      EXPORTING
        domname        = 'ZZFIRFQ_PRODTYP'
        text           = 'X'
        langu          = sy-langu
      TABLES
        dd07v_tab      = lt_idd07v
      EXCEPTIONS
        wrong_textflag = 1
        OTHERS         = 2.

    LOOP AT lt_idd07v ASSIGNING FIELD-SYMBOL(<lfs_idd07v>) WHERE valpos = is_head-prod_type.
      DATA(lv_product) = <lfs_idd07v>-ddtext.
    ENDLOOP.

    CALL FUNCTION 'BAPI_USER_GET_DETAIL'
      EXPORTING
        username = sy-uname
      IMPORTING
        address  = ls_address
      TABLES
        return   = lt_return.

    " Recupero dati Societa'
    SELECT SINGLE *
    FROM t001
    WHERE bukrs = @is_head-bukrs
    AND spras = @sy-langu
    INTO @DATA(ls_t001).

    IF ls_t001-adrnr IS NOT INITIAL.

      SELECT SINGLE *
      FROM adrc
      WHERE addrnumber = @ls_t001-adrnr
      INTO @DATA(ls_adrc).

      SELECT SINGLE landx50
      FROM t005t
      WHERE spras = @sy-langu
      AND land1 = @ls_t001-land1
      INTO @DATA(lv_landx).

    ENDIF.

    " Creazione Firma
    DATA: lv_line TYPE soli.

    lv_line-line = |{ ls_address-firstname }|.
    APPEND lv_line TO lt_body.
    lv_line-line = |--------------------------------------------------|.
    APPEND lv_line TO lt_body.
    lv_line-line = |{ ls_address-fullname }|.
    APPEND lv_line TO lt_body.
    lv_line-line = |{ ls_address-department }|.
    APPEND lv_line TO lt_body.
    lv_line-line = |{ ls_t001-butxt }|.
    APPEND lv_line TO lt_body.
    lv_line-line = |{ ls_adrc-street }|.
    APPEND lv_line TO lt_body.
    lv_line-line = |{ ls_adrc-post_code1 } { ls_t001-ort01 } - { lv_landx }|.
    APPEND lv_line TO lt_body.
    lv_line-line = |Tel: { ls_address-tel1_numbr }|.
    APPEND lv_line TO lt_body.
    lv_line-line = |E-mail: { ls_address-e_mail }|.
    APPEND lv_line TO lt_body.

  ENDIF.

  " Logica Adobe Form
  CALL FUNCTION 'FP_FUNCTION_MODULE_NAME'
    EXPORTING
      i_name     = lc_adobeform
    IMPORTING
      e_funcname = lv_fm_name
    EXCEPTIONS
      OTHERS     = 1.
  IF sy-subrc <> 0. RETURN. ENDIF.

  ls_outputparams-nodialog = abap_true.
  ls_outputparams-getpdf   = abap_true.

  CALL FUNCTION 'FP_JOB_OPEN'
    CHANGING
      ie_outputparams = ls_outputparams
    EXCEPTIONS
      OTHERS          = 1.
  IF sy-subrc <> 0. RETURN. ENDIF.

  ls_docparams-langu   = sy-langu.
  ls_docparams-country = 'IT'.
  ls_docparams-fillable = abap_true.

  CALL FUNCTION lv_fm_name
    EXPORTING
      /1bcdwb/docparams  = ls_docparams
      is_head            = is_head
      it_so              = it_so
      it_issue           = it_issue
      it_quot_block      = it_quot_block
    IMPORTING
      /1bcdwb/formoutput = ls_formoutput
    EXCEPTIONS
      OTHERS             = 1.

  DATA(lv_subrc_form) = sy-subrc.
  CALL FUNCTION 'FP_JOB_CLOSE' EXCEPTIONS OTHERS = 1.

  " Invio Mail
  IF lv_subrc_form = 0 AND ls_formoutput-pdf IS NOT INITIAL.

    CLEAR lt_pdf.
    CALL FUNCTION 'SCMS_XSTRING_TO_BINARY'
      EXPORTING
        buffer     = ls_formoutput-pdf
      TABLES
        binary_tab = lt_pdf.

    lv_size = xstrlen( ls_formoutput-pdf ).

    " Gestione CC
    IF it_recipients_cc IS INITIAL.

      SELECT SINGLE cc1, cc2, cc3
      FROM zfirfq_sendmail
      WHERE zevent = @iv_event
      AND bukrs = @is_head-bukrs
      AND zprodtyp = @is_head-prod_type
      INTO @DATA(ls_cc).

      IF sy-subrc = 0.

        DATA(lv_concat_cc) = |{ ls_cc-cc1 };{ ls_cc-cc2 };{ ls_cc-cc3 }|.

        SPLIT lv_concat_cc AT ';' INTO TABLE DATA(lt_split_cc).

        LOOP AT lt_split_cc INTO DATA(lv_mail_cc).

          CONDENSE lv_mail_cc.

          IF lv_mail_cc IS NOT INITIAL.

            READ TABLE it_recipients_cc TRANSPORTING NO FIELDS
            WITH KEY table_line = lv_mail_cc.

            IF sy-subrc <> 0.
              APPEND lv_mail_cc TO it_recipients_cc.
            ENDIF.

          ENDIF.

        ENDLOOP.

      ENDIF.

    ENDIF.

    " Gestione TO
    IF it_recipients_to IS INITIAL.

      SELECT *
      FROM zi_fi_lc_bpemail
      WHERE BusinessPartner = @iv_confbank
      ORDER BY PRIMARY KEY
      INTO TABLE @DATA(lt_to).

    ENDIF.

    TRY.
        DATA(lo_send_request) = cl_bcs=>create_persistent( ).

        IF lv_email_sender IS NOT INITIAL.
          DATA(lo_sender) = cl_cam_address_bcs=>create_internet_address( lv_email_sender ).
          lo_send_request->set_sender( lo_sender ).
        ENDIF.

        " Creazione documento
        DATA(lo_document) = cl_document_bcs=>create_document(
              i_type    = 'RAW'
              i_text    = lt_body
              i_subject = CONV #( lv_long_subject ) ).

        lo_document->add_attachment(
        i_attachment_type    = 'PDF'
        i_attachment_subject = |Quotation_{ iv_enqid }_{ iv_confbank }|
        i_attachment_size    = lv_size
        i_att_content_hex    = lt_pdf ).

        lo_send_request->set_document( lo_document ).

        " Subject
        lo_send_request->set_message_subject( ip_subject = lv_long_subject ).

        " To
        LOOP AT it_recipients_to INTO DATA(lv_to_mail).
          CHECK lv_to_mail IS NOT INITIAL.
          DATA(lo_recipient_to) = cl_cam_address_bcs=>create_internet_address( CONV #( lv_to_mail ) ).
          lo_send_request->add_recipient( lo_recipient_to ).
        ENDLOOP.

        " CC
        LOOP AT it_recipients_cc INTO DATA(lv_cc_mail).
          CHECK lv_cc_mail IS NOT INITIAL.
          DATA(lo_recipient_cc) = cl_cam_address_bcs=>create_internet_address( CONV #( lv_cc_mail ) ).
          lo_send_request->add_recipient( i_recipient = lo_recipient_cc i_copy = abap_true ).
        ENDLOOP.

        lo_send_request->send( ).
        COMMIT WORK.

      CATCH cx_bcs.
    ENDTRY.

  ENDIF.

ENDFUNCTION.