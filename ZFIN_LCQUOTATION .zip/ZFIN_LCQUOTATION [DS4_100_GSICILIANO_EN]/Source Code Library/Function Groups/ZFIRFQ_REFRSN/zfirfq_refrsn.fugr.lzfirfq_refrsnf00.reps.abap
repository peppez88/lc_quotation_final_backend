*---------------------------------------------------------------------*
*    view related FORM routines
*   generation date: 13.05.2026 at 10:12:01
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

* base table related FORM-routines.............
INCLUDE LSVIMFTX .