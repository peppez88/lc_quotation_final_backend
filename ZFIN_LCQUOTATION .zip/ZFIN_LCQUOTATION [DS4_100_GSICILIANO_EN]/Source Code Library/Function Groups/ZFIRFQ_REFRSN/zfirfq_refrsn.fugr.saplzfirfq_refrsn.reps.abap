* regenerated at 13.05.2026 10:12:01
*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFIRFQ_REFRSNTOP.                 " Global Declarations
  INCLUDE LZFIRFQ_REFRSNUXX.                 " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFIRFQ_REFRSNF...                 " Subroutines
* INCLUDE LZFIRFQ_REFRSNO...                 " PBO-Modules
* INCLUDE LZFIRFQ_REFRSNI...                 " PAI-Modules
* INCLUDE LZFIRFQ_REFRSNE...                 " Events
* INCLUDE LZFIRFQ_REFRSNP...                 " Local class implement.
* INCLUDE LZFIRFQ_REFRSNT99.                 " ABAP Unit tests
  INCLUDE LZFIRFQ_REFRSNF00                       . " subprograms
  INCLUDE LZFIRFQ_REFRSNI00                       . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules