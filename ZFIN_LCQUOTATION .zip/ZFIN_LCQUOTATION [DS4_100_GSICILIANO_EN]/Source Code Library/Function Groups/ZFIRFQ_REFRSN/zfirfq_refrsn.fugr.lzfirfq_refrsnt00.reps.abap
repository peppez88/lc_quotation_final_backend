*---------------------------------------------------------------------*
*    view related data declarations
*   generation date: 13.05.2026 at 10:12:01
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
*...processing: ZFIRFQ_REFRSN...................................*
DATA:  BEGIN OF STATUS_ZFIRFQ_REFRSN                 .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFIRFQ_REFRSN                 .
CONTROLS: TCTRL_ZFIRFQ_REFRSN
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZFIRFQ_REFRSN                 .
TABLES: ZFIRFQ_REFRSN                  .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .