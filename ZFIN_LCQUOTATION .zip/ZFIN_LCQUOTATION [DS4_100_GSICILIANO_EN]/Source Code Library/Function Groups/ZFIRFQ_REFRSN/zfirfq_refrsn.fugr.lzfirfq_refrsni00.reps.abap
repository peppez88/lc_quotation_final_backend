*---------------------------------------------------------------------*
*    view related PAI modules
*   generation date: 13.05.2026 at 10:12:01
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

INCLUDE LSVIMITX . "base table related PAI modules