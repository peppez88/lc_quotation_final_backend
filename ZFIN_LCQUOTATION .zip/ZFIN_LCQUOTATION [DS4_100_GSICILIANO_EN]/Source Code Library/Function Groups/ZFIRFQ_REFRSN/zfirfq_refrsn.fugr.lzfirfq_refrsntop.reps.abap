* regenerated at 13.05.2026 10:12:01
FUNCTION-POOL ZFIRFQ_REFRSN              MESSAGE-ID SV.

* INCLUDE LZFIRFQ_REFRSND...                 " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFIRFQ_REFRSNT00                       . "view rel. data dcl.