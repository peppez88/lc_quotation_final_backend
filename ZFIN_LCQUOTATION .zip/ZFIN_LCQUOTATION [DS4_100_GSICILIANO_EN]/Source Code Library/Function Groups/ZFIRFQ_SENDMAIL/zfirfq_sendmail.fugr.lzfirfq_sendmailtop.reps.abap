* regenerated at 29.06.2026 14:57:59
FUNCTION-POOL ZFIRFQ_SENDMAIL            MESSAGE-ID SV.

* INCLUDE LZFIRFQ_SENDMAILD...               " Local class definition
  INCLUDE LSVIMDAT                                . "general data decl.
  INCLUDE LZFIRFQ_SENDMAILT00                     . "view rel. data dcl.