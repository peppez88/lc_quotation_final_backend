*---------------------------------------------------------------------*
*    view related data declarations
*   generation date: 29.06.2026 at 14:57:59
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*
*...processing: ZFIRFQ_SENDMAIL.................................*
DATA:  BEGIN OF STATUS_ZFIRFQ_SENDMAIL               .   "state vector
         INCLUDE STRUCTURE VIMSTATUS.
DATA:  END OF STATUS_ZFIRFQ_SENDMAIL               .
CONTROLS: TCTRL_ZFIRFQ_SENDMAIL
            TYPE TABLEVIEW USING SCREEN '0001'.
*.........table declarations:.................................*
TABLES: *ZFIRFQ_SENDMAIL               .
TABLES: ZFIRFQ_SENDMAIL                .

* general table data declarations..............
  INCLUDE LSVIMTDT                                .