*---------------------------------------------------------------------*
*    view related FORM routines
*   generation date: 29.06.2026 at 14:57:59
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

* base table related FORM-routines.............
INCLUDE LSVIMFTX .