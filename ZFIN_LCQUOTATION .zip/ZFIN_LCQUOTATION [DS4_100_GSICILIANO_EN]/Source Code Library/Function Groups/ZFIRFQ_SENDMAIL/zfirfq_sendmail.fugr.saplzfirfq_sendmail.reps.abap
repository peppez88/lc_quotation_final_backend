* regenerated at 29.06.2026 14:57:59
*******************************************************************
*   System-defined Include-files.                                 *
*******************************************************************
  INCLUDE LZFIRFQ_SENDMAILTOP.               " Global Declarations
  INCLUDE LZFIRFQ_SENDMAILUXX.               " Function Modules

*******************************************************************
*   User-defined Include-files (if necessary).                    *
*******************************************************************
* INCLUDE LZFIRFQ_SENDMAILF...               " Subroutines
* INCLUDE LZFIRFQ_SENDMAILO...               " PBO-Modules
* INCLUDE LZFIRFQ_SENDMAILI...               " PAI-Modules
* INCLUDE LZFIRFQ_SENDMAILE...               " Events
* INCLUDE LZFIRFQ_SENDMAILP...               " Local class implement.
* INCLUDE LZFIRFQ_SENDMAILT99.               " ABAP Unit tests
  INCLUDE LZFIRFQ_SENDMAILF00                     . " subprograms
  INCLUDE LZFIRFQ_SENDMAILI00                     . " PAI modules
  INCLUDE LSVIMFXX                                . " subprograms
  INCLUDE LSVIMOXX                                . " PBO modules
  INCLUDE LSVIMIXX                                . " PAI modules