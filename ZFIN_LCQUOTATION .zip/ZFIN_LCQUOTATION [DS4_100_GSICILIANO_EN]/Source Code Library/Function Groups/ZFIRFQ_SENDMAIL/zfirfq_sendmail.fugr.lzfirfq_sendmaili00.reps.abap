*---------------------------------------------------------------------*
*    view related PAI modules
*   generation date: 29.06.2026 at 14:57:59
*   view maintenance generator version: #001407#
*---------------------------------------------------------------------*

INCLUDE LSVIMITX . "base table related PAI modules